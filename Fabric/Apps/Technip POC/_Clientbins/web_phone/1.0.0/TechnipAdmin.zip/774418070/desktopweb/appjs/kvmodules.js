define('applicationController',{
    appInit: function(params) {
        skinsInit();
        voltmx.mvc.registry.add("com.technip.admindemo.AppHeader", "AppHeader", "AppHeaderController");
        voltmx.application.registerMaster({
            "namespace": "com.technip.admindemo",
            "classname": "AppHeader",
            "name": "com.technip.admindemo.AppHeader"
        });
        voltmx.mvc.registry.add("com.technip.admindemo.LeftMenu", "LeftMenu", "LeftMenuController");
        voltmx.application.registerMaster({
            "namespace": "com.technip.admindemo",
            "classname": "LeftMenu",
            "name": "com.technip.admindemo.LeftMenu"
        });
        voltmx.mvc.registry.add("com.technip.admindemo.ObservationListElement", "ObservationListElement", "ObservationListElementController");
        voltmx.application.registerMaster({
            "namespace": "com.technip.admindemo",
            "classname": "ObservationListElement",
            "name": "com.technip.admindemo.ObservationListElement"
        });
        voltmx.mvc.registry.add("com.technip.admindemo.PortletHeader", "PortletHeader", "PortletHeaderController");
        voltmx.application.registerMaster({
            "namespace": "com.technip.admindemo",
            "classname": "PortletHeader",
            "name": "com.technip.admindemo.PortletHeader"
        });
        voltmx.mvc.registry.add("com.technip.admindemo.PortletListElement", "PortletListElement", "PortletListElementController");
        voltmx.application.registerMaster({
            "namespace": "com.technip.admindemo",
            "classname": "PortletListElement",
            "name": "com.technip.admindemo.PortletListElement"
        });
        voltmx.mvc.registry.add("com.technip.admindemo.PortletPieFooterElement", "PortletPieFooterElement", "PortletPieFooterElementController");
        voltmx.application.registerMaster({
            "namespace": "com.technip.admindemo",
            "classname": "PortletPieFooterElement",
            "name": "com.technip.admindemo.PortletPieFooterElement"
        });
        voltmx.mvc.registry.add("com.technip.admindemo.ShadowBottom", "ShadowBottom", "ShadowBottomController");
        voltmx.application.registerMaster({
            "namespace": "com.technip.admindemo",
            "classname": "ShadowBottom",
            "name": "com.technip.admindemo.ShadowBottom"
        });
        voltmx.mvc.registry.add("com.technip.admindemo.ShadowRight", "ShadowRight", "ShadowRightController");
        voltmx.application.registerMaster({
            "namespace": "com.technip.admindemo",
            "classname": "ShadowRight",
            "name": "com.technip.admindemo.ShadowRight"
        });
        voltmx.mvc.registry.add("com.technip.admindemo.PortletBar", "PortletBar", "PortletBarController");
        voltmx.application.registerMaster({
            "namespace": "com.technip.admindemo",
            "classname": "PortletBar",
            "name": "com.technip.admindemo.PortletBar"
        });
        voltmx.mvc.registry.add("com.technip.admindemo.PortletList", "PortletList", "PortletListController");
        voltmx.application.registerMaster({
            "namespace": "com.technip.admindemo",
            "classname": "PortletList",
            "name": "com.technip.admindemo.PortletList"
        });
        voltmx.mvc.registry.add("com.technip.admindemo.PortletPieFooter", "PortletPieFooter", "PortletPieFooterController");
        voltmx.application.registerMaster({
            "namespace": "com.technip.admindemo",
            "classname": "PortletPieFooter",
            "name": "com.technip.admindemo.PortletPieFooter"
        });
        voltmx.mvc.registry.add("com.technip.admindemo.PortletTask", "PortletTask", "PortletTaskController");
        voltmx.application.registerMaster({
            "namespace": "com.technip.admindemo",
            "classname": "PortletTask",
            "name": "com.technip.admindemo.PortletTask"
        });
        voltmx.mvc.registry.add("com.technip.admindemo.PortletPie", "PortletPie", "PortletPieController");
        voltmx.application.registerMaster({
            "namespace": "com.technip.admindemo",
            "classname": "PortletPie",
            "name": "com.technip.admindemo.PortletPie"
        });
        voltmx.mvc.registry.add("flxSampleRowTemplate", "flxSampleRowTemplate", "flxSampleRowTemplateController");
        voltmx.mvc.registry.add("flxSectionHeaderTemplate", "flxSectionHeaderTemplate", "flxSectionHeaderTemplateController");
        voltmx.mvc.registry.add("frmHome", "frmHome", "frmHomeController");
        setAppBehaviors();
    },
    postAppInitCallBack: function(eventObj) {},
    appmenuseq: function() {
        new voltmx.mvc.Navigation("frmHome").navigate();
    }
});

define("com/technip/admindemo/AppHeader/userAppHeaderController", [],function() {
    return {};
});
define("com/technip/admindemo/AppHeader/AppHeaderControllerActions", {
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
});
define("com/technip/admindemo/AppHeader/AppHeaderController", ["com/technip/admindemo/AppHeader/userAppHeaderController", "com/technip/admindemo/AppHeader/AppHeaderControllerActions"], function() {
    var controller = require("com/technip/admindemo/AppHeader/userAppHeaderController");
    var actions = require("com/technip/admindemo/AppHeader/AppHeaderControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    return controller;
});

define('com/technip/admindemo/AppHeader/AppHeader',[],function() {
    return function(controller) {
        var AppHeader = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "96dp",
            "id": "AppHeader",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknFlxWhite",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1,
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366]
        }, controller.args[0], "AppHeader"), extendConfig({}, controller.args[1], "AppHeader"), extendConfig({}, controller.args[2], "AppHeader"));
        AppHeader.setDefaultUnit(voltmx.flex.DP);
        var flxLogo = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "96dp",
            "id": "flxLogo",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "255dp",
            "zIndex": 1
        }, controller.args[0], "flxLogo"), extendConfig({}, controller.args[1], "flxLogo"), extendConfig({}, controller.args[2], "flxLogo"));
        flxLogo.setDefaultUnit(voltmx.flex.DP);
        var imgLogo = new voltmx.ui.Image2(extendConfig({
            "height": "100%",
            "id": "imgLogo",
            "isVisible": true,
            "left": "0dp",
            "skin": "slImage",
            "src": "tecniplogo.png",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "imgLogo"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgLogo"), extendConfig({}, controller.args[2], "imgLogo"));
        flxLogo.add(imgLogo);
        var flxDateTime = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "24dp",
            "id": "flxDateTime",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_HORIZONTAL,
            "left": "279dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "400dp"
        }, controller.args[0], "flxDateTime"), extendConfig({}, controller.args[1], "flxDateTime"), extendConfig({}, controller.args[2], "flxDateTime"));
        flxDateTime.setDefaultUnit(voltmx.flex.DP);
        var lblDate = new voltmx.ui.Label(extendConfig({
            "centerY": "50%",
            "height": "24dp",
            "id": "lblDate",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblRegular16",
            "text": "Tuesday, 30 of November 2021",
            "width": voltmx.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblDate"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblDate"), extendConfig({}, controller.args[2], "lblDate"));
        var lblTime = new voltmx.ui.Label(extendConfig({
            "centerY": "50%",
            "height": "24dp",
            "id": "lblTime",
            "isVisible": true,
            "left": "24dp",
            "skin": "sknLblRegular16",
            "text": "16:45",
            "width": voltmx.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblTime"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblTime"), extendConfig({}, controller.args[2], "lblTime"));
        var lblPlace = new voltmx.ui.Label(extendConfig({
            "centerY": "50%",
            "height": "24dp",
            "id": "lblPlace",
            "isVisible": true,
            "left": "24dp",
            "skin": "sknLblRegular16",
            "text": "Paris, FR",
            "width": voltmx.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblPlace"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblPlace"), extendConfig({}, controller.args[2], "lblPlace"));
        flxDateTime.add(lblDate, lblTime, lblPlace);
        var flxGroup = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "44dp",
            "id": "flxGroup",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_HORIZONTAL,
            "isModalContainer": false,
            "right": "48dp",
            "skin": "slFbox",
            "top": "34dp",
            "width": "525dp",
            "zIndex": 1
        }, controller.args[0], "flxGroup"), extendConfig({}, controller.args[1], "flxGroup"), extendConfig({}, controller.args[2], "flxGroup"));
        flxGroup.setDefaultUnit(voltmx.flex.DP);
        var lblCounter = new voltmx.ui.Label(extendConfig({
            "id": "lblCounter",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblRegularOrange10",
            "text": "4",
            "top": "22dp",
            "width": "7dp",
            "zIndex": 1
        }, controller.args[0], "lblCounter"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblCounter"), extendConfig({}, controller.args[2], "lblCounter"));
        var imgNotification = new voltmx.ui.Image2(extendConfig({
            "centerY": "50%",
            "height": "100%",
            "id": "imgNotification",
            "isVisible": true,
            "left": "0dp",
            "skin": "slImage",
            "src": "notification.png",
            "top": "0dp",
            "width": "17dp",
            "zIndex": 1
        }, controller.args[0], "imgNotification"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgNotification"), extendConfig({}, controller.args[2], "imgNotification"));
        var flxDivider1 = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "32dp",
            "id": "flxDivider1",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "25dp",
            "isModalContainer": false,
            "skin": "sknFlxGrey",
            "width": "1dp",
            "zIndex": 1
        }, controller.args[0], "flxDivider1"), extendConfig({}, controller.args[1], "flxDivider1"), extendConfig({}, controller.args[2], "flxDivider1"));
        flxDivider1.setDefaultUnit(voltmx.flex.DP);
        flxDivider1.add();
        var flxSearch = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "32dp",
            "id": "flxSearch",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "25dp",
            "isModalContainer": false,
            "skin": "sknFlxCircleWhiteBorderGrey",
            "width": "200dp",
            "zIndex": 1
        }, controller.args[0], "flxSearch"), extendConfig({}, controller.args[1], "flxSearch"), extendConfig({}, controller.args[2], "flxSearch"));
        flxSearch.setDefaultUnit(voltmx.flex.DP);
        var imgSearch = new voltmx.ui.Image2(extendConfig({
            "centerY": "50%",
            "height": "16dp",
            "id": "imgSearch",
            "isVisible": true,
            "left": "10dp",
            "skin": "slImage",
            "src": "search.png",
            "top": "8dp",
            "width": "16dp",
            "zIndex": 1
        }, controller.args[0], "imgSearch"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgSearch"), extendConfig({}, controller.args[2], "imgSearch"));
        flxSearch.add(imgSearch);
        var flxDivider2 = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "32dp",
            "id": "flxDivider2",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "25dp",
            "isModalContainer": false,
            "skin": "sknFlxGrey",
            "width": "1dp",
            "zIndex": 1
        }, controller.args[0], "flxDivider2"), extendConfig({}, controller.args[1], "flxDivider2"), extendConfig({}, controller.args[2], "flxDivider2"));
        flxDivider2.setDefaultUnit(voltmx.flex.DP);
        flxDivider2.add();
        var flxPerson = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100%",
            "id": "flxPerson",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_HORIZONTAL,
            "reverseLayoutDirection": true,
            "left": "25dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "199dp",
            "zIndex": 1
        }, controller.args[0], "flxPerson"), extendConfig({}, controller.args[1], "flxPerson"), extendConfig({}, controller.args[2], "flxPerson"));
        flxPerson.setDefaultUnit(voltmx.flex.DP);
        var flxPicture = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "44dp",
            "id": "flxPicture",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_HORIZONTAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknFlexCircleGrey",
            "top": "0dp",
            "width": "44dp"
        }, controller.args[0], "flxPicture"), extendConfig({}, controller.args[1], "flxPicture"), extendConfig({}, controller.args[2], "flxPicture"));
        flxPicture.setDefaultUnit(voltmx.flex.DP);
        var imgPicture = new voltmx.ui.Image2(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "id": "imgPicture",
            "isVisible": true,
            "right": "0dp",
            "skin": "slImage",
            "src": "samplepicture.png",
            "top": "0dp",
            "width": voltmx.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "imgPicture"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_CROP,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgPicture"), extendConfig({}, controller.args[2], "imgPicture"));
        flxPicture.add(imgPicture);
        var lblName = new voltmx.ui.Label(extendConfig({
            "centerY": "50%",
            "height": "100%",
            "id": "lblName",
            "isVisible": true,
            "right": "10dp",
            "skin": "sknLblSemibold14",
            "text": "Ambroise Thomas",
            "top": "26dp",
            "width": voltmx.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblName"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblName"), extendConfig({}, controller.args[2], "lblName"));
        flxPerson.add(flxPicture, lblName);
        flxGroup.add(lblCounter, imgNotification, flxDivider1, flxSearch, flxDivider2, flxPerson);
        AppHeader.add(flxLogo, flxDateTime, flxGroup);
        return AppHeader;
    }
})
;
define('com/technip/admindemo/AppHeader/AppHeaderConfig',[],function() {
    return {
        "properties": [],
        "apis": [],
        "events": []
    }
});

define("com/technip/admindemo/LeftMenu/userLeftMenuController", [],function() {
    const SKIN_FLX_SELECTED = 'sknFlxBlue';
    const SKIN_FLX_UNSELECTED = 'sknFlxWhite';
    const SKIN_LBL_SELECTED = 'sknLblWhiteRegular18';
    const SKIN_LBL_UNSELECTED = 'sknLblRegular18';
    const IMG1_SELECTED = 'dashboardsel.png';
    const IMG1_UNSELECTED = 'dashboard.png';
    const IMG2_SELECTED = 'observationsel.png';
    const IMG2_UNSELECTED = 'observation.png';
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {
            this.view.preShow = () => {
                if (!this.initDone) {
                    this.view.flxItem1.onClick = () => {
                        this.view.flxItem2.skin = SKIN_FLX_UNSELECTED;
                        this.view.lblItem2.skin = SKIN_LBL_UNSELECTED;
                        this.view.imgItem2.src = IMG2_UNSELECTED;
                        this.view.flxItem1.skin = SKIN_FLX_SELECTED;
                        this.view.lblItem1.skin = SKIN_LBL_SELECTED;
                        this.view.imgItem1.src = IMG1_SELECTED;
                        this.onMenuSelect('dashboard');
                    };
                    this.view.flxItem2.onClick = () => {
                        this.view.flxItem1.skin = SKIN_FLX_UNSELECTED;
                        this.view.lblItem1.skin = SKIN_LBL_UNSELECTED;
                        this.view.imgItem1.src = IMG1_UNSELECTED;
                        this.view.flxItem2.skin = SKIN_FLX_SELECTED;
                        this.view.lblItem2.skin = SKIN_LBL_SELECTED;
                        this.view.imgItem2.src = IMG2_SELECTED;
                        this.onMenuSelect('observation');
                    };
                    this.initDone = true;
                }
            };
        },
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {},
        onMenuSelect() {}
    };
});
define("com/technip/admindemo/LeftMenu/LeftMenuControllerActions", {
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
});
define("com/technip/admindemo/LeftMenu/LeftMenuController", ["com/technip/admindemo/LeftMenu/userLeftMenuController", "com/technip/admindemo/LeftMenu/LeftMenuControllerActions"], function() {
    var controller = require("com/technip/admindemo/LeftMenu/userLeftMenuController");
    var actions = require("com/technip/admindemo/LeftMenu/LeftMenuControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    return controller;
});

define('com/technip/admindemo/LeftMenu/LeftMenu',[],function() {
    return function(controller) {
        var LeftMenu = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "928dp",
            "id": "LeftMenu",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknFlxWhite",
            "top": "96dp",
            "width": "255dp",
            "zIndex": 1,
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366]
        }, controller.args[0], "LeftMenu"), extendConfig({}, controller.args[1], "LeftMenu"), extendConfig({}, controller.args[2], "LeftMenu"));
        LeftMenu.setDefaultUnit(voltmx.flex.DP);
        var flxItem1 = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "60dp",
            "id": "flxItem1",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknFlxBlue",
            "top": "24dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxItem1"), extendConfig({}, controller.args[1], "flxItem1"), extendConfig({}, controller.args[2], "flxItem1"));
        flxItem1.setDefaultUnit(voltmx.flex.DP);
        var flxItemElement1 = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "27dp",
            "id": "flxItemElement1",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_HORIZONTAL,
            "left": "32dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "width": "192dp",
            "zIndex": 1
        }, controller.args[0], "flxItemElement1"), extendConfig({}, controller.args[1], "flxItemElement1"), extendConfig({}, controller.args[2], "flxItemElement1"));
        flxItemElement1.setDefaultUnit(voltmx.flex.DP);
        var imgItem1 = new voltmx.ui.Image2(extendConfig({
            "height": "27dp",
            "id": "imgItem1",
            "isVisible": true,
            "left": "0dp",
            "skin": "slImage",
            "src": "dashboardsel.png",
            "top": "0dp",
            "width": "27dp",
            "zIndex": 1
        }, controller.args[0], "imgItem1"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgItem1"), extendConfig({}, controller.args[2], "imgItem1"));
        var lblItem1 = new voltmx.ui.Label(extendConfig({
            "height": "100%",
            "id": "lblItem1",
            "isVisible": true,
            "left": "5dp",
            "skin": "sknLblWhiteRegular18",
            "text": "Dashboard",
            "top": "0dp",
            "width": voltmx.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblItem1"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblItem1"), extendConfig({}, controller.args[2], "lblItem1"));
        flxItemElement1.add(imgItem1, lblItem1);
        flxItem1.add(flxItemElement1);
        var flxItem2 = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "60dp",
            "id": "flxItem2",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknFlxWhite",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxItem2"), extendConfig({}, controller.args[1], "flxItem2"), extendConfig({}, controller.args[2], "flxItem2"));
        flxItem2.setDefaultUnit(voltmx.flex.DP);
        var flxItemElement2 = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "27dp",
            "id": "flxItemElement2",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_HORIZONTAL,
            "left": "32dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "width": "210dp",
            "zIndex": 1
        }, controller.args[0], "flxItemElement2"), extendConfig({}, controller.args[1], "flxItemElement2"), extendConfig({}, controller.args[2], "flxItemElement2"));
        flxItemElement2.setDefaultUnit(voltmx.flex.DP);
        var imgItem2 = new voltmx.ui.Image2(extendConfig({
            "height": "27dp",
            "id": "imgItem2",
            "isVisible": true,
            "left": "0dp",
            "skin": "slImage",
            "src": "observation.png",
            "top": "0dp",
            "width": "27dp",
            "zIndex": 1
        }, controller.args[0], "imgItem2"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgItem2"), extendConfig({}, controller.args[2], "imgItem2"));
        var lblItem2 = new voltmx.ui.Label(extendConfig({
            "height": "100%",
            "id": "lblItem2",
            "isVisible": true,
            "left": "5dp",
            "skin": "sknLblRegular18",
            "text": "Observation Cards",
            "top": "0dp",
            "width": voltmx.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblItem2"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblItem2"), extendConfig({}, controller.args[2], "lblItem2"));
        flxItemElement2.add(imgItem2, lblItem2);
        flxItem2.add(flxItemElement2);
        var flxItem3 = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "60dp",
            "id": "flxItem3",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknFlxWhite",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxItem3"), extendConfig({}, controller.args[1], "flxItem3"), extendConfig({}, controller.args[2], "flxItem3"));
        flxItem3.setDefaultUnit(voltmx.flex.DP);
        var flxItemElement3 = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "27dp",
            "id": "flxItemElement3",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_HORIZONTAL,
            "left": "32dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "width": "210dp",
            "zIndex": 1
        }, controller.args[0], "flxItemElement3"), extendConfig({}, controller.args[1], "flxItemElement3"), extendConfig({}, controller.args[2], "flxItemElement3"));
        flxItemElement3.setDefaultUnit(voltmx.flex.DP);
        var imgItem3 = new voltmx.ui.Image2(extendConfig({
            "height": "27dp",
            "id": "imgItem3",
            "isVisible": true,
            "left": "0dp",
            "skin": "slImage",
            "src": "paper.png",
            "top": "0dp",
            "width": "27dp",
            "zIndex": 1
        }, controller.args[0], "imgItem3"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgItem3"), extendConfig({}, controller.args[2], "imgItem3"));
        var lblItem3 = new voltmx.ui.Label(extendConfig({
            "height": "100%",
            "id": "lblItem3",
            "isVisible": true,
            "left": "5dp",
            "skin": "sknLblRegular18",
            "text": "Vehicle Inspection",
            "top": "0dp",
            "width": voltmx.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblItem3"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblItem3"), extendConfig({}, controller.args[2], "lblItem3"));
        flxItemElement3.add(imgItem3, lblItem3);
        flxItem3.add(flxItemElement3);
        var flxItem4 = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "60dp",
            "id": "flxItem4",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknFlxWhite",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxItem4"), extendConfig({}, controller.args[1], "flxItem4"), extendConfig({}, controller.args[2], "flxItem4"));
        flxItem4.setDefaultUnit(voltmx.flex.DP);
        var flxItemElement4 = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "27dp",
            "id": "flxItemElement4",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_HORIZONTAL,
            "left": "32dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "width": "192dp",
            "zIndex": 1
        }, controller.args[0], "flxItemElement4"), extendConfig({}, controller.args[1], "flxItemElement4"), extendConfig({}, controller.args[2], "flxItemElement4"));
        flxItemElement4.setDefaultUnit(voltmx.flex.DP);
        var imgItem4 = new voltmx.ui.Image2(extendConfig({
            "height": "27dp",
            "id": "imgItem4",
            "isVisible": true,
            "left": "0dp",
            "skin": "slImage",
            "src": "message.png",
            "top": "0dp",
            "width": "27dp",
            "zIndex": 1
        }, controller.args[0], "imgItem4"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgItem4"), extendConfig({}, controller.args[2], "imgItem4"));
        var lblItem4 = new voltmx.ui.Label(extendConfig({
            "height": "100%",
            "id": "lblItem4",
            "isVisible": true,
            "left": "5dp",
            "skin": "sknLblRegular18",
            "text": "Messages",
            "top": "0dp",
            "width": voltmx.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblItem4"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblItem4"), extendConfig({}, controller.args[2], "lblItem4"));
        flxItemElement4.add(imgItem4, lblItem4);
        flxItem4.add(flxItemElement4);
        var flxItem5 = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "60dp",
            "id": "flxItem5",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknFlxWhite",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxItem5"), extendConfig({}, controller.args[1], "flxItem5"), extendConfig({}, controller.args[2], "flxItem5"));
        flxItem5.setDefaultUnit(voltmx.flex.DP);
        var flxItemElement5 = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "27dp",
            "id": "flxItemElement5",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_HORIZONTAL,
            "left": "32dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "width": "192dp",
            "zIndex": 1
        }, controller.args[0], "flxItemElement5"), extendConfig({}, controller.args[1], "flxItemElement5"), extendConfig({}, controller.args[2], "flxItemElement5"));
        flxItemElement5.setDefaultUnit(voltmx.flex.DP);
        var imgItem5 = new voltmx.ui.Image2(extendConfig({
            "height": "27dp",
            "id": "imgItem5",
            "isVisible": true,
            "left": "0dp",
            "skin": "slImage",
            "src": "password.png",
            "top": "0dp",
            "width": "27dp",
            "zIndex": 1
        }, controller.args[0], "imgItem5"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgItem5"), extendConfig({}, controller.args[2], "imgItem5"));
        var lblItem5 = new voltmx.ui.Label(extendConfig({
            "height": "100%",
            "id": "lblItem5",
            "isVisible": true,
            "left": "5dp",
            "skin": "sknLblRegular18",
            "text": "Admin",
            "top": "0dp",
            "width": voltmx.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblItem5"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblItem5"), extendConfig({}, controller.args[2], "lblItem5"));
        flxItemElement5.add(imgItem5, lblItem5);
        flxItem5.add(flxItemElement5);
        var flxItem6 = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "60dp",
            "id": "flxItem6",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknFlxWhite",
            "top": "100dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxItem6"), extendConfig({}, controller.args[1], "flxItem6"), extendConfig({}, controller.args[2], "flxItem6"));
        flxItem6.setDefaultUnit(voltmx.flex.DP);
        var flxItemElement6 = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "27dp",
            "id": "flxItemElement6",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_HORIZONTAL,
            "left": "32dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "width": "192dp",
            "zIndex": 1
        }, controller.args[0], "flxItemElement6"), extendConfig({}, controller.args[1], "flxItemElement6"), extendConfig({}, controller.args[2], "flxItemElement6"));
        flxItemElement6.setDefaultUnit(voltmx.flex.DP);
        var imgItem6 = new voltmx.ui.Image2(extendConfig({
            "height": "27dp",
            "id": "imgItem6",
            "isVisible": true,
            "left": "0dp",
            "skin": "slImage",
            "src": "plus.png",
            "top": "0dp",
            "width": "27dp",
            "zIndex": 1
        }, controller.args[0], "imgItem6"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgItem6"), extendConfig({}, controller.args[2], "imgItem6"));
        var lblItem6 = new voltmx.ui.Label(extendConfig({
            "height": "100%",
            "id": "lblItem6",
            "isVisible": true,
            "left": "5dp",
            "skin": "sknLblRegular18",
            "text": "Add More Apps",
            "top": "0dp",
            "width": voltmx.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblItem6"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblItem6"), extendConfig({}, controller.args[2], "lblItem6"));
        flxItemElement6.add(imgItem6, lblItem6);
        flxItem6.add(flxItemElement6);
        LeftMenu.add(flxItem1, flxItem2, flxItem3, flxItem4, flxItem5, flxItem6);
        LeftMenu.compInstData = {}
        return LeftMenu;
    }
})
;
define('com/technip/admindemo/LeftMenu/LeftMenuConfig',[],function() {
    return {
        "properties": [],
        "apis": [],
        "events": ["onMenuSelect"]
    }
});

define("com/technip/admindemo/ObservationListElement/userObservationListElementController", [],function() {
    const STATUS_OPENED = 'Opened';
    const STATUS_ASSIGNED = 'Assigned';
    const STATUS_CLOSED = 'Closed';
    const STATUS_MISSED = 'Missed';
    const STATUS_UNKNOWN = 'Unknown';
    const SKIN_OPENED = 'sknFlxRoundedLightGreen';
    const SKIN_ASSIGNED = 'sknFlxRoundedLightBlue';
    const SKIN_CLOSED = 'sknFlxRoundedGrey';
    const SKIN_MISSED = 'sknFlxRoundedLightPink';
    const SKIN_UNKNOWN = 'sknFlxRoundedWhiteBorderGrey';
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {
            this.view.preShow = () => {
                this.view.onClick = () => {
                    this.onClickElement();
                };
                switch (this.status) {
                    case STATUS_OPENED:
                        this.view.flxContent.skin = SKIN_OPENED;
                        this.view.lblStatus.text = STATUS_OPENED;
                        break;
                    case STATUS_ASSIGNED:
                        this.view.flxContent.skin = SKIN_ASSIGNED;
                        this.view.lblStatus.text = STATUS_ASSIGNED;
                        break;
                    case STATUS_CLOSED:
                        this.view.flxContent.skin = SKIN_CLOSED;
                        this.view.lblStatus.text = STATUS_CLOSED;
                        break;
                    case STATUS_MISSED:
                        this.view.flxContent.skin = SKIN_MISSED;
                        this.view.lblStatus.text = STATUS_MISSED;
                        break;
                    default:
                        this.view.flxContent.skin = SKIN_UNKNOWN;
                        this.view.lblStatus.text = STATUS_UNKNOWN;
                        break;
                }
            };
        },
        //Logic for getters/setters of custom properties
        initGettersSetters() {
            defineGetter(this, 'status', () => {
                return this._status;
            });
            defineSetter(this, 'status', value => {
                if (value !== STATUS_OPENED && value !== STATUS_ASSIGNED && value !== STATUS_CLOSED && value !== STATUS_MISSED) {
                    value = STATUS_UNKNOWN;
                }
                this._status = value;
            });
            defineGetter(this, 'elementId', () => {
                return this._elementId;
            });
            defineSetter(this, 'elementId', value => {
                this._elementId = value;
            });
        },
        onClickElement() {}
    };
});
define("com/technip/admindemo/ObservationListElement/ObservationListElementControllerActions", {
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
});
define("com/technip/admindemo/ObservationListElement/ObservationListElementController", ["com/technip/admindemo/ObservationListElement/userObservationListElementController", "com/technip/admindemo/ObservationListElement/ObservationListElementControllerActions"], function() {
    var controller = require("com/technip/admindemo/ObservationListElement/userObservationListElementController");
    var actions = require("com/technip/admindemo/ObservationListElement/ObservationListElementControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        defineSetter(this, "title", function(val) {
            this.view.lblTitle.text = val;
        });
        defineGetter(this, "title", function() {
            return this.view.lblTitle.text;
        });
        defineSetter(this, "name", function(val) {
            this.view.lblName.text = val;
        });
        defineGetter(this, "name", function() {
            return this.view.lblName.text;
        });
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    return controller;
});

define('com/technip/admindemo/ObservationListElement/ObservationListElement',[],function() {
    return function(controller) {
        var ObservationListElement = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "40dp",
            "id": "ObservationListElement",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "620dp",
            "zIndex": 1,
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366]
        }, controller.args[0], "ObservationListElement"), extendConfig({}, controller.args[1], "ObservationListElement"), extendConfig({}, controller.args[2], "ObservationListElement"));
        ObservationListElement.setDefaultUnit(voltmx.flex.DP);
        var flxContent = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100%",
            "id": "flxContent",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_HORIZONTAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknFlxRoundedWhiteBorderGrey",
            "top": "0dp",
            "width": "100%"
        }, controller.args[0], "flxContent"), extendConfig({}, controller.args[1], "flxContent"), extendConfig({}, controller.args[2], "flxContent"));
        flxContent.setDefaultUnit(voltmx.flex.DP);
        var lblTitle = new voltmx.ui.Label(extendConfig({
            "height": "100%",
            "id": "lblTitle",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblRegular16",
            "text": "Label",
            "top": "0dp",
            "width": "30%",
            "zIndex": 1
        }, controller.args[0], "lblTitle"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [5, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblTitle"), extendConfig({}, controller.args[2], "lblTitle"));
        var lblName = new voltmx.ui.Label(extendConfig({
            "height": "100%",
            "id": "lblName",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblRegular16",
            "text": "Label",
            "top": "0dp",
            "width": "40%",
            "zIndex": 1
        }, controller.args[0], "lblName"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblName"), extendConfig({}, controller.args[2], "lblName"));
        var lblStatus = new voltmx.ui.Label(extendConfig({
            "height": "100%",
            "id": "lblStatus",
            "isVisible": true,
            "left": "0%",
            "skin": "sknLblRegular16",
            "text": "Label",
            "top": "0%",
            "width": "30%",
            "zIndex": 1
        }, controller.args[0], "lblStatus"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
            "padding": [0, 0, 5, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblStatus"), extendConfig({}, controller.args[2], "lblStatus"));
        flxContent.add(lblTitle, lblName, lblStatus);
        ObservationListElement.add(flxContent);
        ObservationListElement.compInstData = {}
        return ObservationListElement;
    }
})
;
define('com/technip/admindemo/ObservationListElement/ObservationListElementConfig',[],function() {
    return {
        "properties": [{
            "name": "title",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "name",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "status",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "elementId",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }],
        "apis": [],
        "events": ["onClickElement"]
    }
});

define("com/technip/admindemo/PortletHeader/userPortletHeaderController", [],function() {
    return {};
});
define("com/technip/admindemo/PortletHeader/PortletHeaderControllerActions", {
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
});
define("com/technip/admindemo/PortletHeader/PortletHeaderController", ["com/technip/admindemo/PortletHeader/userPortletHeaderController", "com/technip/admindemo/PortletHeader/PortletHeaderControllerActions"], function() {
    var controller = require("com/technip/admindemo/PortletHeader/userPortletHeaderController");
    var actions = require("com/technip/admindemo/PortletHeader/PortletHeaderControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        defineSetter(this, "title", function(val) {
            this.view.lblTitle.text = val;
        });
        defineGetter(this, "title", function() {
            return this.view.lblTitle.text;
        });
        defineSetter(this, "showZoom", function(val) {
            this.view.imgZoom.isVisible = val;
        });
        defineGetter(this, "showZoom", function() {
            return this.view.imgZoom.isVisible;
        });
        defineSetter(this, "showFilter", function(val) {
            this.view.imgFilter.isVisible = val;
        });
        defineGetter(this, "showFilter", function() {
            return this.view.imgFilter.isVisible;
        });
        defineSetter(this, "subtitle", function(val) {
            this.view.lblSubtitle.text = val;
        });
        defineGetter(this, "subtitle", function() {
            return this.view.lblSubtitle.text;
        });
        defineSetter(this, "showSubtitle", function(val) {
            this.view.flxBottom.isVisible = val;
        });
        defineGetter(this, "showSubtitle", function() {
            return this.view.flxBottom.isVisible;
        });
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    return controller;
});

define('com/technip/admindemo/PortletHeader/PortletHeader',[],function() {
    return function(controller) {
        var PortletHeader = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "isMaster": true,
            "id": "PortletHeader",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_VERTICAL,
            "left": "24dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "24dp",
            "width": "344dp",
            "zIndex": 1,
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366]
        }, controller.args[0], "PortletHeader"), extendConfig({}, controller.args[1], "PortletHeader"), extendConfig({}, controller.args[2], "PortletHeader"));
        PortletHeader.setDefaultUnit(voltmx.flex.DP);
        var flxTop = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "27dp",
            "id": "flxTop",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%"
        }, controller.args[0], "flxTop"), extendConfig({}, controller.args[1], "flxTop"), extendConfig({}, controller.args[2], "flxTop"));
        flxTop.setDefaultUnit(voltmx.flex.DP);
        var lblTitle = new voltmx.ui.Label(extendConfig({
            "centerY": "50%",
            "height": "27dp",
            "id": "lblTitle",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblRegular18",
            "text": "Observation Card Requests",
            "top": 0,
            "width": "260dp",
            "zIndex": 1
        }, controller.args[0], "lblTitle"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblTitle"), extendConfig({}, controller.args[2], "lblTitle"));
        var flxIcons = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "27dp",
            "id": "flxIcons",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_HORIZONTAL,
            "reverseLayoutDirection": true,
            "isModalContainer": false,
            "right": "0dp",
            "skin": "slFbox",
            "top": "0dp",
            "width": voltmx.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "flxIcons"), extendConfig({}, controller.args[1], "flxIcons"), extendConfig({}, controller.args[2], "flxIcons"));
        flxIcons.setDefaultUnit(voltmx.flex.DP);
        var imgZoom = new voltmx.ui.Image2(extendConfig({
            "centerY": "50%",
            "height": "18dp",
            "id": "imgZoom",
            "isVisible": true,
            "left": "30dp",
            "right": "0dp",
            "skin": "slImage",
            "src": "fullscreen.png",
            "width": "18dp",
            "zIndex": 1
        }, controller.args[0], "imgZoom"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgZoom"), extendConfig({}, controller.args[2], "imgZoom"));
        var imgFilter = new voltmx.ui.Image2(extendConfig({
            "centerY": "50%",
            "height": "18dp",
            "id": "imgFilter",
            "isVisible": true,
            "skin": "slImage",
            "src": "filter.png",
            "width": "18dp",
            "zIndex": 1
        }, controller.args[0], "imgFilter"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgFilter"), extendConfig({}, controller.args[2], "imgFilter"));
        flxIcons.add(imgZoom, imgFilter);
        flxTop.add(lblTitle, flxIcons);
        var flxBottom = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "27dp",
            "id": "flxBottom",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%"
        }, controller.args[0], "flxBottom"), extendConfig({}, controller.args[1], "flxBottom"), extendConfig({}, controller.args[2], "flxBottom"));
        flxBottom.setDefaultUnit(voltmx.flex.DP);
        var lblSubtitle = new voltmx.ui.Label(extendConfig({
            "centerY": "50%",
            "height": "27dp",
            "id": "lblSubtitle",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblGrey16",
            "text": "Who made more observations ?",
            "top": 0,
            "width": "260dp",
            "zIndex": 1
        }, controller.args[0], "lblSubtitle"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblSubtitle"), extendConfig({}, controller.args[2], "lblSubtitle"));
        flxBottom.add(lblSubtitle);
        PortletHeader.add(flxTop, flxBottom);
        PortletHeader.compInstData = {}
        return PortletHeader;
    }
})
;
define('com/technip/admindemo/PortletHeader/PortletHeaderConfig',[],function() {
    return {
        "properties": [{
            "name": "title",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "showZoom",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "showFilter",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "subtitle",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "showSubtitle",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }],
        "apis": [],
        "events": []
    }
});

define("com/technip/admindemo/PortletListElement/userPortletListElementController", [],function() {
    const STATUS_OPENED = 'Opened';
    const STATUS_ASSIGNED = 'Assigned';
    const STATUS_CLOSED = 'Closed';
    const STATUS_MISSED = 'Missed';
    const STATUS_UNKNOWN = 'Unknown';
    const SKIN_OPENED = 'sknFlxRoundedLightGreen';
    const SKIN_ASSIGNED = 'sknFlxRoundedLightBlue';
    const SKIN_CLOSED = 'sknFlxRoundedGrey';
    const SKIN_MISSED = 'sknFlxRoundedLightPink';
    const SKIN_UNKNOWN = 'sknFlxRoundedWhiteBorderGrey';
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {
            this.view.preShow = () => {
                this.view.onClick = () => {
                    this.onClickElement();
                };
                switch (this.status) {
                    case STATUS_OPENED:
                        this.view.flxContent.skin = SKIN_OPENED;
                        this.view.lblStatus.text = STATUS_OPENED;
                        break;
                    case STATUS_ASSIGNED:
                        this.view.flxContent.skin = SKIN_ASSIGNED;
                        this.view.lblStatus.text = STATUS_ASSIGNED;
                        break;
                    case STATUS_CLOSED:
                        this.view.flxContent.skin = SKIN_CLOSED;
                        this.view.lblStatus.text = STATUS_CLOSED;
                        break;
                    case STATUS_MISSED:
                        this.view.flxContent.skin = SKIN_MISSED;
                        this.view.lblStatus.text = STATUS_MISSED;
                        break;
                    default:
                        this.view.flxContent.skin = SKIN_UNKNOWN;
                        this.view.lblStatus.text = STATUS_UNKNOWN;
                        break;
                }
            };
        },
        //Logic for getters/setters of custom properties
        initGettersSetters() {
            defineGetter(this, 'status', () => {
                return this._status;
            });
            defineSetter(this, 'status', value => {
                if (value !== STATUS_OPENED && value !== STATUS_ASSIGNED && value !== STATUS_CLOSED && value !== STATUS_MISSED) {
                    value = STATUS_UNKNOWN;
                }
                this._status = value;
            });
            defineGetter(this, 'elementId', () => {
                return this._elementId;
            });
            defineSetter(this, 'elementId', value => {
                this._elementId = value;
            });
        },
        onClickElement() {}
    };
});
define("com/technip/admindemo/PortletListElement/PortletListElementControllerActions", {
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
});
define("com/technip/admindemo/PortletListElement/PortletListElementController", ["com/technip/admindemo/PortletListElement/userPortletListElementController", "com/technip/admindemo/PortletListElement/PortletListElementControllerActions"], function() {
    var controller = require("com/technip/admindemo/PortletListElement/userPortletListElementController");
    var actions = require("com/technip/admindemo/PortletListElement/PortletListElementControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        defineSetter(this, "title", function(val) {
            this.view.lblTitle.text = val;
        });
        defineGetter(this, "title", function() {
            return this.view.lblTitle.text;
        });
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    return controller;
});

define('com/technip/admindemo/PortletListElement/PortletListElement',[],function() {
    return function(controller) {
        var PortletListElement = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "40dp",
            "id": "PortletListElement",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "340dp",
            "zIndex": 1,
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366]
        }, controller.args[0], "PortletListElement"), extendConfig({}, controller.args[1], "PortletListElement"), extendConfig({}, controller.args[2], "PortletListElement"));
        PortletListElement.setDefaultUnit(voltmx.flex.DP);
        var flxContent = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100%",
            "id": "flxContent",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknFlxRoundedWhiteBorderGrey",
            "top": "0dp",
            "width": "100%"
        }, controller.args[0], "flxContent"), extendConfig({}, controller.args[1], "flxContent"), extendConfig({}, controller.args[2], "flxContent"));
        flxContent.setDefaultUnit(voltmx.flex.DP);
        var lblTitle = new voltmx.ui.Label(extendConfig({
            "height": "100%",
            "id": "lblTitle",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblRegular16",
            "text": "Label",
            "top": "0dp",
            "width": "60%",
            "zIndex": 1
        }, controller.args[0], "lblTitle"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [5, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblTitle"), extendConfig({}, controller.args[2], "lblTitle"));
        var lblStatus = new voltmx.ui.Label(extendConfig({
            "height": "100%",
            "id": "lblStatus",
            "isVisible": true,
            "left": "60%",
            "skin": "sknLblRegular16",
            "text": "Label",
            "top": "0%",
            "width": "40%",
            "zIndex": 1
        }, controller.args[0], "lblStatus"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
            "padding": [0, 0, 5, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblStatus"), extendConfig({}, controller.args[2], "lblStatus"));
        flxContent.add(lblTitle, lblStatus);
        PortletListElement.add(flxContent);
        PortletListElement.compInstData = {}
        return PortletListElement;
    }
})
;
define('com/technip/admindemo/PortletListElement/PortletListElementConfig',[],function() {
    return {
        "properties": [{
            "name": "title",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "status",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "elementId",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }],
        "apis": [],
        "events": ["onClickElement"]
    }
});

define("com/technip/admindemo/PortletPieFooterElement/userPortletPieFooterElementController", [],function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {},
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {}
    };
});
define("com/technip/admindemo/PortletPieFooterElement/PortletPieFooterElementControllerActions", {
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
});
define("com/technip/admindemo/PortletPieFooterElement/PortletPieFooterElementController", ["com/technip/admindemo/PortletPieFooterElement/userPortletPieFooterElementController", "com/technip/admindemo/PortletPieFooterElement/PortletPieFooterElementControllerActions"], function() {
    var controller = require("com/technip/admindemo/PortletPieFooterElement/userPortletPieFooterElementController");
    var actions = require("com/technip/admindemo/PortletPieFooterElement/PortletPieFooterElementControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        defineSetter(this, "skinCircle", function(val) {
            this.view.flxCircle.skin = val;
        });
        defineGetter(this, "skinCircle", function() {
            return this.view.flxCircle.skin;
        });
        defineSetter(this, "label", function(val) {
            this.view.lblElement.text = val;
        });
        defineGetter(this, "label", function() {
            return this.view.lblElement.text;
        });
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    return controller;
});

define('com/technip/admindemo/PortletPieFooterElement/PortletPieFooterElement',[],function() {
    return function(controller) {
        var PortletPieFooterElement = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "32dp",
            "id": "PortletPieFooterElement",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "48dp",
            "zIndex": 1,
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366]
        }, controller.args[0], "PortletPieFooterElement"), extendConfig({}, controller.args[1], "PortletPieFooterElement"), extendConfig({}, controller.args[2], "PortletPieFooterElement"));
        PortletPieFooterElement.setDefaultUnit(voltmx.flex.DP);
        var flxCircle = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "12dp",
            "id": "flxCircle",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknFlexCircleDarkBlue",
            "top": "0dp",
            "width": "12dp",
            "zIndex": 1
        }, controller.args[0], "flxCircle"), extendConfig({}, controller.args[1], "flxCircle"), extendConfig({}, controller.args[2], "flxCircle"));
        flxCircle.setDefaultUnit(voltmx.flex.DP);
        flxCircle.add();
        var flxLabel = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "20dp",
            "id": "flxLabel",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxLabel"), extendConfig({}, controller.args[1], "flxLabel"), extendConfig({}, controller.args[2], "flxLabel"));
        flxLabel.setDefaultUnit(voltmx.flex.DP);
        var lblElement = new voltmx.ui.Label(extendConfig({
            "height": "100%",
            "id": "lblElement",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblGrey12",
            "text": "Label",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblElement"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblElement"), extendConfig({}, controller.args[2], "lblElement"));
        flxLabel.add(lblElement);
        PortletPieFooterElement.add(flxCircle, flxLabel);
        PortletPieFooterElement.compInstData = {}
        return PortletPieFooterElement;
    }
})
;
define('com/technip/admindemo/PortletPieFooterElement/PortletPieFooterElementConfig',[],function() {
    return {
        "properties": [{
            "name": "skinCircle",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "label",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }],
        "apis": [],
        "events": []
    }
});

define("com/technip/admindemo/ShadowBottom/userShadowBottomController", [],function() {
    return {};
});
define("com/technip/admindemo/ShadowBottom/ShadowBottomControllerActions", {
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
});
define("com/technip/admindemo/ShadowBottom/ShadowBottomController", ["com/technip/admindemo/ShadowBottom/userShadowBottomController", "com/technip/admindemo/ShadowBottom/ShadowBottomControllerActions"], function() {
    var controller = require("com/technip/admindemo/ShadowBottom/userShadowBottomController");
    var actions = require("com/technip/admindemo/ShadowBottom/ShadowBottomControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    return controller;
});

define('com/technip/admindemo/ShadowBottom/ShadowBottom',[],function() {
    return function(controller) {
        var ShadowBottom = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "10dp",
            "id": "ShadowBottom",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknFlxShadowBottom",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1,
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366]
        }, controller.args[0], "ShadowBottom"), extendConfig({}, controller.args[1], "ShadowBottom"), extendConfig({}, controller.args[2], "ShadowBottom"));
        ShadowBottom.setDefaultUnit(voltmx.flex.DP);
        ShadowBottom.add();
        ShadowBottom.compInstData = {}
        return ShadowBottom;
    }
})
;
define("com/technip/admindemo/ShadowRight/userShadowRightController", [],function() {
    return {};
});
define("com/technip/admindemo/ShadowRight/ShadowRightControllerActions", {
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
});
define("com/technip/admindemo/ShadowRight/ShadowRightController", ["com/technip/admindemo/ShadowRight/userShadowRightController", "com/technip/admindemo/ShadowRight/ShadowRightControllerActions"], function() {
    var controller = require("com/technip/admindemo/ShadowRight/userShadowRightController");
    var actions = require("com/technip/admindemo/ShadowRight/ShadowRightControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    return controller;
});

define('com/technip/admindemo/ShadowRight/ShadowRight',[],function() {
    return function(controller) {
        var ShadowRight = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "100%",
            "id": "ShadowRight",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknFlxShadowRight",
            "top": "0dp",
            "width": "10dp",
            "zIndex": 1,
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366]
        }, controller.args[0], "ShadowRight"), extendConfig({}, controller.args[1], "ShadowRight"), extendConfig({}, controller.args[2], "ShadowRight"));
        ShadowRight.setDefaultUnit(voltmx.flex.DP);
        ShadowRight.add();
        ShadowRight.compInstData = {}
        return ShadowRight;
    }
})
;
define("com/technip/admindemo/PortletBar/userPortletBarController", [],function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {},
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {}
    };
});
define("com/technip/admindemo/PortletBar/PortletBarControllerActions", {
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
});
define("com/technip/admindemo/PortletBar/PortletBarController", ["com/technip/admindemo/PortletBar/userPortletBarController", "com/technip/admindemo/PortletBar/PortletBarControllerActions"], function() {
    var controller = require("com/technip/admindemo/PortletBar/userPortletBarController");
    var actions = require("com/technip/admindemo/PortletBar/PortletBarControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    return controller;
});

define('com/technip/admindemo/PortletBar/PortletBar',[],function() {
    return function(controller) {
        var PortletBar = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "475dp",
            "id": "PortletBar",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFlxWhiteBorderGrey",
            "top": "0dp",
            "width": "306dp",
            "zIndex": 1,
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366]
        }, controller.args[0], "PortletBar"), extendConfig({}, controller.args[1], "PortletBar"), extendConfig({}, controller.args[2], "PortletBar"));
        PortletBar.setDefaultUnit(voltmx.flex.DP);
        var PortletHeader = new com.technip.admindemo.PortletHeader(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
            "id": "PortletHeader",
            "isVisible": true,
            "left": "24dp",
            "masterType": constants.MASTER_TYPE_USERWIDGET,
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "24dp",
            "width": "323dp",
            "zIndex": 1,
            "overrides": {
                "imgFilter": {
                    "isVisible": false
                },
                "imgZoom": {
                    "isVisible": false
                },
                "lblTitle": {
                    "text": "Working Areas"
                },
                "PortletHeader": {
                    "right": "viz.val_cleared",
                    "bottom": "viz.val_cleared",
                    "height": "viz.val_cleared",
                    "minWidth": "viz.val_cleared",
                    "minHeight": "viz.val_cleared",
                    "maxWidth": "viz.val_cleared",
                    "maxHeight": "viz.val_cleared",
                    "centerX": "viz.val_cleared",
                    "centerY": "viz.val_cleared"
                }
            }
        }, controller.args[0], "PortletHeader"), extendConfig({
            "overrides": {}
        }, controller.args[1], "PortletHeader"), extendConfig({
            "overrides": {}
        }, controller.args[2], "PortletHeader"));
        var imgBar = new voltmx.ui.Image2(extendConfig({
            "bottom": "24dp",
            "centerX": "50%",
            "height": "320dp",
            "id": "imgBar",
            "isVisible": true,
            "left": "90dp",
            "skin": "slImage",
            "src": "histo.png",
            "width": "258dp",
            "zIndex": 1
        }, controller.args[0], "imgBar"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgBar"), extendConfig({}, controller.args[2], "imgBar"));
        PortletBar.add(PortletHeader, imgBar);
        PortletBar.compInstData = {
            "PortletHeader": {
                "title": "Working Areas",
                "right": "",
                "bottom": "",
                "height": "",
                "minWidth": "",
                "minHeight": "",
                "maxWidth": "",
                "maxHeight": "",
                "centerX": "",
                "centerY": ""
            }
        }
        return PortletBar;
    }
})
;
define('com/technip/admindemo/PortletBar/PortletBarConfig',[],function() {
    return {
        "properties": [],
        "apis": [],
        "events": []
    }
});

define("com/technip/admindemo/PortletList/userPortletListController", [],function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {
            this.view.postShow = () => {
                this.reload();
            };
        },
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {
            defineGetter(this, 'data', () => {
                return this._data;
            });
            defineSetter(this, 'data', value => {
                this._data = value;
            });
        },
        onSelectElement() {},
        reload() {
            const data = this.data.data;
            this.view.flxElements.removeAll();
            data.forEach((element, index) => {
                const cmpElement = new com.technip.admindemo.PortletListElement({
                    id: `cmpElement${index}`,
                    top: '24dp'
                }, {}, {});
                cmpElement.elementId = element.id;
                cmpElement.title = element.title;
                cmpElement.status = element.status;
                cmpElement.onClickElement = () => {
                    this.onSelectElement(element.id);
                };
                this.view.flxElements.add(cmpElement);
            });
            this.view.flxElements.forceLayout();
        }
    };
});
define("com/technip/admindemo/PortletList/PortletListControllerActions", {
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
});
define("com/technip/admindemo/PortletList/PortletListController", ["com/technip/admindemo/PortletList/userPortletListController", "com/technip/admindemo/PortletList/PortletListControllerActions"], function() {
    var controller = require("com/technip/admindemo/PortletList/userPortletListController");
    var actions = require("com/technip/admindemo/PortletList/PortletListControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        defineSetter(this, "title", function(val) {
            this.view.portletHeader.title = val;
        });
        defineGetter(this, "title", function() {
            return this.view.portletHeader.title;
        });
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    return controller;
});

define('com/technip/admindemo/PortletList/PortletList',[],function() {
    return function(controller) {
        var PortletList = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "475dp",
            "id": "PortletList",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFlxWhiteBorderGrey",
            "top": "0dp",
            "width": "392dp",
            "zIndex": 1,
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366]
        }, controller.args[0], "PortletList"), extendConfig({}, controller.args[1], "PortletList"), extendConfig({}, controller.args[2], "PortletList"));
        PortletList.setDefaultUnit(voltmx.flex.DP);
        var portletHeader = new com.technip.admindemo.PortletHeader(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
            "id": "portletHeader",
            "isVisible": true,
            "left": "24dp",
            "masterType": constants.MASTER_TYPE_USERWIDGET,
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "24dp",
            "width": "344dp",
            "zIndex": 1,
            "overrides": {
                "flxBottom": {
                    "isVisible": false
                },
                "lblTitle": {
                    "text": "Observation Card Requests"
                },
                "PortletHeader": {
                    "right": "viz.val_cleared",
                    "bottom": "viz.val_cleared",
                    "height": "viz.val_cleared",
                    "minWidth": "viz.val_cleared",
                    "minHeight": "viz.val_cleared",
                    "maxWidth": "viz.val_cleared",
                    "maxHeight": "viz.val_cleared",
                    "centerX": "viz.val_cleared",
                    "centerY": "viz.val_cleared"
                }
            }
        }, controller.args[0], "portletHeader"), extendConfig({
            "overrides": {}
        }, controller.args[1], "portletHeader"), extendConfig({
            "overrides": {}
        }, controller.args[2], "portletHeader"));
        var flxElements = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "clipBounds": true,
            "height": "384dp",
            "id": "flxElements",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_VERTICAL,
            "left": "104dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "50dp",
            "width": "340dp",
            "zIndex": 1
        }, controller.args[0], "flxElements"), extendConfig({}, controller.args[1], "flxElements"), extendConfig({}, controller.args[2], "flxElements"));
        flxElements.setDefaultUnit(voltmx.flex.DP);
        var element1 = new com.technip.admindemo.PortletListElement(extendConfig({
            "height": "40dp",
            "id": "element1",
            "isVisible": true,
            "left": "0dp",
            "masterType": constants.MASTER_TYPE_USERWIDGET,
            "isModalContainer": false,
            "skin": "sknFlxRoundedLightGreen",
            "top": "24dp",
            "width": "340dp",
            "zIndex": 1,
            "overrides": {
                "lblTitle": {
                    "text": "card1"
                },
                "PortletListElement": {
                    "right": "viz.val_cleared",
                    "bottom": "viz.val_cleared",
                    "minWidth": "viz.val_cleared",
                    "minHeight": "viz.val_cleared",
                    "maxWidth": "viz.val_cleared",
                    "maxHeight": "viz.val_cleared",
                    "centerX": "viz.val_cleared",
                    "centerY": "viz.val_cleared"
                }
            }
        }, controller.args[0], "element1"), extendConfig({
            "overrides": {}
        }, controller.args[1], "element1"), extendConfig({
            "overrides": {}
        }, controller.args[2], "element1"));
        element1.status = "Opened";
        element1.elementId = "";
        var element2 = new com.technip.admindemo.PortletListElement(extendConfig({
            "height": "40dp",
            "id": "element2",
            "isVisible": true,
            "left": "0dp",
            "masterType": constants.MASTER_TYPE_USERWIDGET,
            "isModalContainer": false,
            "skin": "sknFlxRoundedLightGreen",
            "top": "24dp",
            "width": "340dp",
            "zIndex": 1,
            "overrides": {
                "lblTitle": {
                    "text": "card2"
                },
                "PortletListElement": {
                    "right": "viz.val_cleared",
                    "bottom": "viz.val_cleared",
                    "minWidth": "viz.val_cleared",
                    "minHeight": "viz.val_cleared",
                    "maxWidth": "viz.val_cleared",
                    "maxHeight": "viz.val_cleared",
                    "centerX": "viz.val_cleared",
                    "centerY": "viz.val_cleared"
                }
            }
        }, controller.args[0], "element2"), extendConfig({
            "overrides": {}
        }, controller.args[1], "element2"), extendConfig({
            "overrides": {}
        }, controller.args[2], "element2"));
        element2.status = "Closed";
        element2.elementId = "";
        var element3 = new com.technip.admindemo.PortletListElement(extendConfig({
            "height": "40dp",
            "id": "element3",
            "isVisible": true,
            "left": "0dp",
            "masterType": constants.MASTER_TYPE_USERWIDGET,
            "isModalContainer": false,
            "skin": "sknFlxRoundedLightGreen",
            "top": "24dp",
            "width": "340dp",
            "zIndex": 1,
            "overrides": {
                "lblTitle": {
                    "text": "card3"
                },
                "PortletListElement": {
                    "right": "viz.val_cleared",
                    "bottom": "viz.val_cleared",
                    "minWidth": "viz.val_cleared",
                    "minHeight": "viz.val_cleared",
                    "maxWidth": "viz.val_cleared",
                    "maxHeight": "viz.val_cleared",
                    "centerX": "viz.val_cleared",
                    "centerY": "viz.val_cleared"
                }
            }
        }, controller.args[0], "element3"), extendConfig({
            "overrides": {}
        }, controller.args[1], "element3"), extendConfig({
            "overrides": {}
        }, controller.args[2], "element3"));
        element3.status = "Missed";
        element3.elementId = "";
        var element4 = new com.technip.admindemo.PortletListElement(extendConfig({
            "height": "40dp",
            "id": "element4",
            "isVisible": true,
            "left": "0dp",
            "masterType": constants.MASTER_TYPE_USERWIDGET,
            "isModalContainer": false,
            "skin": "sknFlxRoundedLightGreen",
            "top": "24dp",
            "width": "340dp",
            "zIndex": 1,
            "overrides": {
                "lblTitle": {
                    "text": "card4"
                },
                "PortletListElement": {
                    "right": "viz.val_cleared",
                    "bottom": "viz.val_cleared",
                    "minWidth": "viz.val_cleared",
                    "minHeight": "viz.val_cleared",
                    "maxWidth": "viz.val_cleared",
                    "maxHeight": "viz.val_cleared",
                    "centerX": "viz.val_cleared",
                    "centerY": "viz.val_cleared"
                }
            }
        }, controller.args[0], "element4"), extendConfig({
            "overrides": {}
        }, controller.args[1], "element4"), extendConfig({
            "overrides": {}
        }, controller.args[2], "element4"));
        element4.status = "Assigned";
        element4.elementId = "";
        var element5 = new com.technip.admindemo.PortletListElement(extendConfig({
            "height": "40dp",
            "id": "element5",
            "isVisible": true,
            "left": "0dp",
            "masterType": constants.MASTER_TYPE_USERWIDGET,
            "isModalContainer": false,
            "skin": "sknFlxRoundedLightGreen",
            "top": "24dp",
            "width": "340dp",
            "zIndex": 1,
            "overrides": {
                "lblTitle": {
                    "text": "card5"
                },
                "PortletListElement": {
                    "right": "viz.val_cleared",
                    "bottom": "viz.val_cleared",
                    "minWidth": "viz.val_cleared",
                    "minHeight": "viz.val_cleared",
                    "maxWidth": "viz.val_cleared",
                    "maxHeight": "viz.val_cleared",
                    "centerX": "viz.val_cleared",
                    "centerY": "viz.val_cleared"
                }
            }
        }, controller.args[0], "element5"), extendConfig({
            "overrides": {}
        }, controller.args[1], "element5"), extendConfig({
            "overrides": {}
        }, controller.args[2], "element5"));
        element5.status = "Unknown";
        element5.elementId = "";
        var element6 = new com.technip.admindemo.PortletListElement(extendConfig({
            "height": "40dp",
            "id": "element6",
            "isVisible": true,
            "left": "0dp",
            "masterType": constants.MASTER_TYPE_USERWIDGET,
            "isModalContainer": false,
            "skin": "sknFlxRoundedLightGreen",
            "top": "24dp",
            "width": "340dp",
            "zIndex": 1,
            "overrides": {
                "lblTitle": {
                    "text": "card6"
                },
                "PortletListElement": {
                    "right": "viz.val_cleared",
                    "bottom": "viz.val_cleared",
                    "minWidth": "viz.val_cleared",
                    "minHeight": "viz.val_cleared",
                    "maxWidth": "viz.val_cleared",
                    "maxHeight": "viz.val_cleared",
                    "centerX": "viz.val_cleared",
                    "centerY": "viz.val_cleared"
                }
            }
        }, controller.args[0], "element6"), extendConfig({
            "overrides": {}
        }, controller.args[1], "element6"), extendConfig({
            "overrides": {}
        }, controller.args[2], "element6"));
        element6.status = "Opened";
        element6.elementId = "";
        flxElements.add(element1, element2, element3, element4, element5, element6);
        PortletList.add(portletHeader, flxElements);
        PortletList.compInstData = {
            "portletHeader": {
                "title": "Observation Card Requests",
                "right": "",
                "bottom": "",
                "height": "",
                "minWidth": "",
                "minHeight": "",
                "maxWidth": "",
                "maxHeight": "",
                "centerX": "",
                "centerY": ""
            },
            "element1": {
                "title": "card1",
                "right": "",
                "bottom": "",
                "minWidth": "",
                "minHeight": "",
                "maxWidth": "",
                "maxHeight": "",
                "centerX": "",
                "centerY": ""
            },
            "element2": {
                "title": "card2",
                "right": "",
                "bottom": "",
                "minWidth": "",
                "minHeight": "",
                "maxWidth": "",
                "maxHeight": "",
                "centerX": "",
                "centerY": ""
            },
            "element3": {
                "title": "card3",
                "right": "",
                "bottom": "",
                "minWidth": "",
                "minHeight": "",
                "maxWidth": "",
                "maxHeight": "",
                "centerX": "",
                "centerY": ""
            },
            "element4": {
                "title": "card4",
                "right": "",
                "bottom": "",
                "minWidth": "",
                "minHeight": "",
                "maxWidth": "",
                "maxHeight": "",
                "centerX": "",
                "centerY": ""
            },
            "element5": {
                "title": "card5",
                "right": "",
                "bottom": "",
                "minWidth": "",
                "minHeight": "",
                "maxWidth": "",
                "maxHeight": "",
                "centerX": "",
                "centerY": ""
            },
            "element6": {
                "title": "card6",
                "right": "",
                "bottom": "",
                "minWidth": "",
                "minHeight": "",
                "maxWidth": "",
                "maxHeight": "",
                "centerX": "",
                "centerY": ""
            }
        }
        return PortletList;
    }
})
;
define('com/technip/admindemo/PortletList/PortletListConfig',[],function() {
    return {
        "properties": [{
            "name": "title",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "data",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }],
        "apis": ["reload"],
        "events": ["onSelectElement"]
    }
});

define("com/technip/admindemo/PortletPieFooter/userPortletPieFooterController", [],function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {},
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {}
    };
});
define("com/technip/admindemo/PortletPieFooter/PortletPieFooterControllerActions", {
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
});
define("com/technip/admindemo/PortletPieFooter/PortletPieFooterController", ["com/technip/admindemo/PortletPieFooter/userPortletPieFooterController", "com/technip/admindemo/PortletPieFooter/PortletPieFooterControllerActions"], function() {
    var controller = require("com/technip/admindemo/PortletPieFooter/userPortletPieFooterController");
    var actions = require("com/technip/admindemo/PortletPieFooter/PortletPieFooterControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    return controller;
});

define('com/technip/admindemo/PortletPieFooter/PortletPieFooter',[],function() {
    return function(controller) {
        var PortletPieFooter = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "32dp",
            "id": "PortletPieFooter",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_HORIZONTAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "240dp",
            "zIndex": 1,
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366]
        }, controller.args[0], "PortletPieFooter"), extendConfig({}, controller.args[1], "PortletPieFooter"), extendConfig({}, controller.args[2], "PortletPieFooter"));
        PortletPieFooter.setDefaultUnit(voltmx.flex.DP);
        var element1 = new com.technip.admindemo.PortletPieFooterElement(extendConfig({
            "height": "32dp",
            "id": "element1",
            "isVisible": true,
            "left": "0dp",
            "masterType": constants.MASTER_TYPE_USERWIDGET,
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "48dp",
            "zIndex": 1,
            "overrides": {
                "lblElement": {
                    "text": "CTJV"
                },
                "flxCircle": {
                    "skin": "sknFlexCircleBlue"
                },
                "PortletPieFooterElement": {
                    "right": "viz.val_cleared",
                    "bottom": "viz.val_cleared",
                    "minWidth": "viz.val_cleared",
                    "minHeight": "viz.val_cleared",
                    "maxWidth": "viz.val_cleared",
                    "maxHeight": "viz.val_cleared",
                    "centerX": "viz.val_cleared",
                    "centerY": "viz.val_cleared"
                }
            }
        }, controller.args[0], "element1"), extendConfig({
            "overrides": {}
        }, controller.args[1], "element1"), extendConfig({
            "overrides": {}
        }, controller.args[2], "element1"));
        var element2 = new com.technip.admindemo.PortletPieFooterElement(extendConfig({
            "height": "32dp",
            "id": "element2",
            "isVisible": true,
            "left": "0dp",
            "masterType": constants.MASTER_TYPE_USERWIDGET,
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "48dp",
            "zIndex": 1,
            "overrides": {
                "lblElement": {
                    "text": "ACTS"
                },
                "flxCircle": {
                    "skin": "sknFlexCircleBlueGreen"
                },
                "PortletPieFooterElement": {
                    "right": "viz.val_cleared",
                    "bottom": "viz.val_cleared",
                    "minWidth": "viz.val_cleared",
                    "minHeight": "viz.val_cleared",
                    "maxWidth": "viz.val_cleared",
                    "maxHeight": "viz.val_cleared",
                    "centerX": "viz.val_cleared",
                    "centerY": "viz.val_cleared"
                }
            }
        }, controller.args[0], "element2"), extendConfig({
            "overrides": {}
        }, controller.args[1], "element2"), extendConfig({
            "overrides": {}
        }, controller.args[2], "element2"));
        var element3 = new com.technip.admindemo.PortletPieFooterElement(extendConfig({
            "height": "32dp",
            "id": "element3",
            "isVisible": true,
            "left": "0dp",
            "masterType": constants.MASTER_TYPE_USERWIDGET,
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "48dp",
            "zIndex": 1,
            "overrides": {
                "lblElement": {
                    "text": "Metito"
                },
                "flxCircle": {
                    "skin": "sknFlexCircleViolet"
                },
                "PortletPieFooterElement": {
                    "right": "viz.val_cleared",
                    "bottom": "viz.val_cleared",
                    "minWidth": "viz.val_cleared",
                    "minHeight": "viz.val_cleared",
                    "maxWidth": "viz.val_cleared",
                    "maxHeight": "viz.val_cleared",
                    "centerX": "viz.val_cleared",
                    "centerY": "viz.val_cleared"
                }
            }
        }, controller.args[0], "element3"), extendConfig({
            "overrides": {}
        }, controller.args[1], "element3"), extendConfig({
            "overrides": {}
        }, controller.args[2], "element3"));
        var element4 = new com.technip.admindemo.PortletPieFooterElement(extendConfig({
            "height": "32dp",
            "id": "element4",
            "isVisible": true,
            "left": "0dp",
            "masterType": constants.MASTER_TYPE_USERWIDGET,
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "48dp",
            "zIndex": 1,
            "overrides": {
                "lblElement": {
                    "text": "ACME"
                },
                "flxCircle": {
                    "skin": "sknFlexCircleGrey"
                },
                "PortletPieFooterElement": {
                    "right": "viz.val_cleared",
                    "bottom": "viz.val_cleared",
                    "minWidth": "viz.val_cleared",
                    "minHeight": "viz.val_cleared",
                    "maxWidth": "viz.val_cleared",
                    "maxHeight": "viz.val_cleared",
                    "centerX": "viz.val_cleared",
                    "centerY": "viz.val_cleared"
                }
            }
        }, controller.args[0], "element4"), extendConfig({
            "overrides": {}
        }, controller.args[1], "element4"), extendConfig({
            "overrides": {}
        }, controller.args[2], "element4"));
        var element5 = new com.technip.admindemo.PortletPieFooterElement(extendConfig({
            "height": "32dp",
            "id": "element5",
            "isVisible": true,
            "left": "0dp",
            "masterType": constants.MASTER_TYPE_USERWIDGET,
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "48dp",
            "zIndex": 1,
            "overrides": {
                "lblElement": {
                    "text": "Others"
                },
                "flxCircle": {
                    "skin": "sknFlexCircleDarkBlue"
                },
                "PortletPieFooterElement": {
                    "right": "viz.val_cleared",
                    "bottom": "viz.val_cleared",
                    "minWidth": "viz.val_cleared",
                    "minHeight": "viz.val_cleared",
                    "maxWidth": "viz.val_cleared",
                    "maxHeight": "viz.val_cleared",
                    "centerX": "viz.val_cleared",
                    "centerY": "viz.val_cleared"
                }
            }
        }, controller.args[0], "element5"), extendConfig({
            "overrides": {}
        }, controller.args[1], "element5"), extendConfig({
            "overrides": {}
        }, controller.args[2], "element5"));
        PortletPieFooter.add(element1, element2, element3, element4, element5);
        PortletPieFooter.compInstData = {
            "element1": {
                "label": "CTJV",
                "skinCircle": "sknFlexCircleBlue",
                "right": "",
                "bottom": "",
                "minWidth": "",
                "minHeight": "",
                "maxWidth": "",
                "maxHeight": "",
                "centerX": "",
                "centerY": ""
            },
            "element2": {
                "label": "ACTS",
                "skinCircle": "sknFlexCircleBlueGreen",
                "right": "",
                "bottom": "",
                "minWidth": "",
                "minHeight": "",
                "maxWidth": "",
                "maxHeight": "",
                "centerX": "",
                "centerY": ""
            },
            "element3": {
                "label": "Metito",
                "skinCircle": "sknFlexCircleViolet",
                "right": "",
                "bottom": "",
                "minWidth": "",
                "minHeight": "",
                "maxWidth": "",
                "maxHeight": "",
                "centerX": "",
                "centerY": ""
            },
            "element4": {
                "label": "ACME",
                "skinCircle": "sknFlexCircleGrey",
                "right": "",
                "bottom": "",
                "minWidth": "",
                "minHeight": "",
                "maxWidth": "",
                "maxHeight": "",
                "centerX": "",
                "centerY": ""
            },
            "element5": {
                "label": "Others",
                "skinCircle": "sknFlexCircleDarkBlue",
                "right": "",
                "bottom": "",
                "minWidth": "",
                "minHeight": "",
                "maxWidth": "",
                "maxHeight": "",
                "centerX": "",
                "centerY": ""
            }
        }
        return PortletPieFooter;
    }
})
;
define('com/technip/admindemo/PortletPieFooter/PortletPieFooterConfig',[],function() {
    return {
        "properties": [],
        "apis": [],
        "events": []
    }
});

define("com/technip/admindemo/PortletTask/userPortletTaskController", [],function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {},
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {}
    };
});
define("com/technip/admindemo/PortletTask/PortletTaskControllerActions", {
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
});
define("com/technip/admindemo/PortletTask/PortletTaskController", ["com/technip/admindemo/PortletTask/userPortletTaskController", "com/technip/admindemo/PortletTask/PortletTaskControllerActions"], function() {
    var controller = require("com/technip/admindemo/PortletTask/userPortletTaskController");
    var actions = require("com/technip/admindemo/PortletTask/PortletTaskControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    return controller;
});

define('com/technip/admindemo/PortletTask/PortletTask',[],function() {
    return function(controller) {
        var PortletTask = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "475dp",
            "id": "PortletTask",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_VERTICAL,
            "left": "26dp",
            "isModalContainer": false,
            "skin": "slFlxWhiteBorderGrey",
            "top": "0dp",
            "width": "701dp",
            "zIndex": 1,
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366]
        }, controller.args[0], "PortletTask"), extendConfig({}, controller.args[1], "PortletTask"), extendConfig({}, controller.args[2], "PortletTask"));
        PortletTask.setDefaultUnit(voltmx.flex.DP);
        var PortletHeader = new com.technip.admindemo.PortletHeader(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
            "id": "PortletHeader",
            "isVisible": true,
            "left": "24dp",
            "masterType": constants.MASTER_TYPE_USERWIDGET,
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "24dp",
            "width": "653dp",
            "zIndex": 1,
            "overrides": {
                "imgFilter": {
                    "isVisible": false
                },
                "flxBottom": {
                    "isVisible": false
                },
                "imgZoom": {
                    "isVisible": true
                },
                "lblTitle": {
                    "text": "Assign a Task"
                },
                "PortletHeader": {
                    "right": "viz.val_cleared",
                    "bottom": "viz.val_cleared",
                    "height": "viz.val_cleared",
                    "minWidth": "viz.val_cleared",
                    "minHeight": "viz.val_cleared",
                    "maxWidth": "viz.val_cleared",
                    "maxHeight": "viz.val_cleared",
                    "centerX": "viz.val_cleared",
                    "centerY": "viz.val_cleared"
                }
            }
        }, controller.args[0], "PortletHeader"), extendConfig({
            "overrides": {}
        }, controller.args[1], "PortletHeader"), extendConfig({
            "overrides": {}
        }, controller.args[2], "PortletHeader"));
        var flxField1 = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "40dp",
            "id": "flxField1",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "26dp",
            "isModalContainer": false,
            "skin": "sknFlxRoundedGrey",
            "top": "24dp",
            "width": "340dp",
            "zIndex": 1
        }, controller.args[0], "flxField1"), extendConfig({}, controller.args[1], "flxField1"), extendConfig({}, controller.args[2], "flxField1"));
        flxField1.setDefaultUnit(voltmx.flex.DP);
        var lbl1 = new voltmx.ui.Label(extendConfig({
            "height": "100%",
            "id": "lbl1",
            "isVisible": true,
            "left": "10dp",
            "skin": "sknLblRegular16",
            "text": "Choose the task",
            "top": "0dp",
            "width": voltmx.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lbl1"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lbl1"), extendConfig({}, controller.args[2], "lbl1"));
        var img1 = new voltmx.ui.Image2(extendConfig({
            "centerY": "50%",
            "height": "19dp",
            "id": "img1",
            "isVisible": true,
            "right": "10dp",
            "skin": "slImage",
            "src": "arrowdown.png",
            "top": "0dp",
            "width": "19dp",
            "zIndex": 1
        }, controller.args[0], "img1"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "img1"), extendConfig({}, controller.args[2], "img1"));
        flxField1.add(lbl1, img1);
        var flxField2 = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "40dp",
            "id": "flxField2",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "26dp",
            "isModalContainer": false,
            "skin": "sknFlxRoundedGrey",
            "top": "24dp",
            "width": "340dp",
            "zIndex": 1
        }, controller.args[0], "flxField2"), extendConfig({}, controller.args[1], "flxField2"), extendConfig({}, controller.args[2], "flxField2"));
        flxField2.setDefaultUnit(voltmx.flex.DP);
        var lbl2 = new voltmx.ui.Label(extendConfig({
            "height": "100%",
            "id": "lbl2",
            "isVisible": true,
            "left": "10dp",
            "skin": "sknLblRegular16",
            "text": "Choose an assignee",
            "top": "0dp",
            "width": voltmx.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lbl2"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lbl2"), extendConfig({}, controller.args[2], "lbl2"));
        var img2 = new voltmx.ui.Image2(extendConfig({
            "centerY": "50%",
            "height": "19dp",
            "id": "img2",
            "isVisible": true,
            "right": "10dp",
            "skin": "slImage",
            "src": "arrowdown.png",
            "top": "0dp",
            "width": "19dp",
            "zIndex": 1
        }, controller.args[0], "img2"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "img2"), extendConfig({}, controller.args[2], "img2"));
        flxField2.add(lbl2, img2);
        var flxField3 = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "40dp",
            "id": "flxField3",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "26dp",
            "isModalContainer": false,
            "skin": "sknFlxRoundedGrey",
            "top": "24dp",
            "width": "340dp",
            "zIndex": 1
        }, controller.args[0], "flxField3"), extendConfig({}, controller.args[1], "flxField3"), extendConfig({}, controller.args[2], "flxField3"));
        flxField3.setDefaultUnit(voltmx.flex.DP);
        var lbl3 = new voltmx.ui.Label(extendConfig({
            "height": "100%",
            "id": "lbl3",
            "isVisible": true,
            "left": "10dp",
            "skin": "sknLblRegular16",
            "text": "Choose a due date",
            "top": "0dp",
            "width": voltmx.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lbl3"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lbl3"), extendConfig({}, controller.args[2], "lbl3"));
        var img3 = new voltmx.ui.Image2(extendConfig({
            "centerY": "50%",
            "height": "19dp",
            "id": "img3",
            "isVisible": true,
            "right": "10dp",
            "skin": "slImage",
            "src": "calendar.png",
            "top": "0dp",
            "width": "19dp",
            "zIndex": 1
        }, controller.args[0], "img3"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "img3"), extendConfig({}, controller.args[2], "img3"));
        flxField3.add(lbl3, img3);
        var flxFiel4 = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "104dp",
            "id": "flxFiel4",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "26dp",
            "isModalContainer": false,
            "skin": "sknFlxRoundedGrey",
            "top": "24dp",
            "width": "649dp",
            "zIndex": 1
        }, controller.args[0], "flxFiel4"), extendConfig({}, controller.args[1], "flxFiel4"), extendConfig({}, controller.args[2], "flxFiel4"));
        flxFiel4.setDefaultUnit(voltmx.flex.DP);
        var lbl4 = new voltmx.ui.Label(extendConfig({
            "height": "40dp",
            "id": "lbl4",
            "isVisible": true,
            "left": "10dp",
            "skin": "sknLblRegular16",
            "text": "Add any additional comments:",
            "top": "0dp",
            "width": voltmx.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lbl4"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lbl4"), extendConfig({}, controller.args[2], "lbl4"));
        flxFiel4.add(lbl4);
        var flxAssign = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "clipBounds": true,
            "height": "40dp",
            "id": "flxAssign",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "isModalContainer": false,
            "skin": "sknFlxBlue",
            "top": "24dp",
            "width": "123dp",
            "zIndex": 1
        }, controller.args[0], "flxAssign"), extendConfig({}, controller.args[1], "flxAssign"), extendConfig({}, controller.args[2], "flxAssign"));
        flxAssign.setDefaultUnit(voltmx.flex.DP);
        var lblAssign = new voltmx.ui.Label(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "100%",
            "id": "lblAssign",
            "isVisible": true,
            "skin": "sknLblWhiteRegular14",
            "text": "ASSIGN",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblAssign"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblAssign"), extendConfig({}, controller.args[2], "lblAssign"));
        flxAssign.add(lblAssign);
        PortletTask.add(PortletHeader, flxField1, flxField2, flxField3, flxFiel4, flxAssign);
        PortletTask.compInstData = {
            "PortletHeader": {
                "title": "Assign a Task",
                "right": "",
                "bottom": "",
                "height": "",
                "minWidth": "",
                "minHeight": "",
                "maxWidth": "",
                "maxHeight": "",
                "centerX": "",
                "centerY": ""
            }
        }
        return PortletTask;
    }
})
;
define('com/technip/admindemo/PortletTask/PortletTaskConfig',[],function() {
    return {
        "properties": [],
        "apis": [],
        "events": []
    }
});

define("com/technip/admindemo/PortletPie/userPortletPieController", [],function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {},
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {}
    };
});
define("com/technip/admindemo/PortletPie/PortletPieControllerActions", {
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
});
define("com/technip/admindemo/PortletPie/PortletPieController", ["com/technip/admindemo/PortletPie/userPortletPieController", "com/technip/admindemo/PortletPie/PortletPieControllerActions"], function() {
    var controller = require("com/technip/admindemo/PortletPie/userPortletPieController");
    var actions = require("com/technip/admindemo/PortletPie/PortletPieControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    return controller;
});

define('com/technip/admindemo/PortletPie/PortletPie',[],function() {
    return function(controller) {
        var PortletPie = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "475dp",
            "id": "PortletPie",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFlxWhiteBorderGrey",
            "top": "0dp",
            "width": "371dp",
            "zIndex": 1,
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366]
        }, controller.args[0], "PortletPie"), extendConfig({}, controller.args[1], "PortletPie"), extendConfig({}, controller.args[2], "PortletPie"));
        PortletPie.setDefaultUnit(voltmx.flex.DP);
        var portletHeader = new com.technip.admindemo.PortletHeader(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
            "id": "portletHeader",
            "isVisible": true,
            "left": "24dp",
            "masterType": constants.MASTER_TYPE_USERWIDGET,
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "24dp",
            "width": "323dp",
            "zIndex": 1,
            "overrides": {
                "imgFilter": {
                    "isVisible": false
                },
                "imgZoom": {
                    "isVisible": false
                },
                "lblTitle": {
                    "text": "Observation Companies"
                },
                "PortletHeader": {
                    "right": "viz.val_cleared",
                    "bottom": "viz.val_cleared",
                    "height": "viz.val_cleared",
                    "minWidth": "viz.val_cleared",
                    "minHeight": "viz.val_cleared",
                    "maxWidth": "viz.val_cleared",
                    "maxHeight": "viz.val_cleared",
                    "centerX": "viz.val_cleared",
                    "centerY": "viz.val_cleared"
                }
            }
        }, controller.args[0], "portletHeader"), extendConfig({
            "overrides": {}
        }, controller.args[1], "portletHeader"), extendConfig({
            "overrides": {}
        }, controller.args[2], "portletHeader"));
        var imgPie = new voltmx.ui.Image2(extendConfig({
            "centerX": "50%",
            "height": "323dp",
            "id": "imgPie",
            "isVisible": true,
            "left": "106dp",
            "skin": "slImage",
            "src": "pie_blue.png",
            "top": "90dp",
            "width": "323dp",
            "zIndex": 1
        }, controller.args[0], "imgPie"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgPie"), extendConfig({}, controller.args[2], "imgPie"));
        var portletPieFooter = new com.technip.admindemo.PortletPieFooter(extendConfig({
            "bottom": "20dp",
            "centerX": "50%",
            "height": "32dp",
            "id": "portletPieFooter",
            "isVisible": true,
            "left": "24dp",
            "masterType": constants.MASTER_TYPE_USERWIDGET,
            "isModalContainer": false,
            "skin": "slFbox",
            "width": "240dp",
            "zIndex": 1,
            "overrides": {
                "PortletPieFooter": {
                    "right": "viz.val_cleared",
                    "top": "viz.val_cleared",
                    "minWidth": "viz.val_cleared",
                    "minHeight": "viz.val_cleared",
                    "maxWidth": "viz.val_cleared",
                    "maxHeight": "viz.val_cleared",
                    "centerY": "viz.val_cleared"
                }
            }
        }, controller.args[0], "portletPieFooter"), extendConfig({
            "overrides": {}
        }, controller.args[1], "portletPieFooter"), extendConfig({
            "overrides": {}
        }, controller.args[2], "portletPieFooter"));
        PortletPie.add(portletHeader, imgPie, portletPieFooter);
        PortletPie.compInstData = {
            "portletHeader": {
                "title": "Observation Companies",
                "right": "",
                "bottom": "",
                "height": "",
                "minWidth": "",
                "minHeight": "",
                "maxWidth": "",
                "maxHeight": "",
                "centerX": "",
                "centerY": ""
            },
            "portletPieFooter": {
                "right": "",
                "top": "",
                "minWidth": "",
                "minHeight": "",
                "maxWidth": "",
                "maxHeight": "",
                "centerY": ""
            }
        }
        return PortletPie;
    }
})
;
define('com/technip/admindemo/PortletPie/PortletPieConfig',[],function() {
    return {
        "properties": [],
        "apis": [],
        "events": []
    }
});

define("flxSampleRowTemplate", [],function() {
    return function(controller) {
        var flxSampleRowTemplate = new voltmx.ui.FlexContainer({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "75dp",
            "id": "flxSampleRowTemplate",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "isModalContainer": false,
            "skin": "sknSampleRowTemplate",
            "width": "100%"
        }, {}, {});
        flxSampleRowTemplate.setDefaultUnit(voltmx.flex.DP);
        var lblHeading = new voltmx.ui.Label({
            "id": "lblHeading",
            "isVisible": true,
            "left": "4%",
            "maxWidth": "50%",
            "skin": "sknLblRowHeading",
            "text": "Heading",
            "textStyle": {},
            "top": "8.00%",
            "width": "45%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var lblDescription = new voltmx.ui.Label({
            "bottom": "10%",
            "id": "lblDescription",
            "isVisible": true,
            "left": "4%",
            "maxNumberOfLines": 3,
            "maxWidth": "70%",
            "skin": "sknLblDescription",
            "text": "Sub-Heading",
            "textStyle": {},
            "textTruncatePosition": constants.TEXT_TRUNCATE_NONE,
            "top": "42%",
            "width": "70%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var lblTime = new voltmx.ui.Label({
            "id": "lblTime",
            "isVisible": true,
            "right": "9%",
            "skin": "sknLblTimeStamp",
            "text": "Timestamp",
            "textStyle": {},
            "top": "10%",
            "width": voltmx.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var lblStrip = new voltmx.ui.Label({
            "height": "100%",
            "id": "lblStrip",
            "isVisible": true,
            "left": "0dp",
            "maxWidth": "1%",
            "skin": "sknLblStrip",
            "textStyle": {},
            "top": "0dp",
            "width": voltmx.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxSampleRowTemplate.add(lblHeading, lblDescription, lblTime, lblStrip);
        return flxSampleRowTemplate;
    }
})
;
define("flxSectionHeaderTemplate", [],function() {
    return function(controller) {
        var flxSectionHeaderTemplate = new voltmx.ui.FlexContainer({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "45dp",
            "id": "flxSectionHeaderTemplate",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "isModalContainer": false,
            "skin": "sknSampleSectionHeaderTemplate",
            "width": "100%"
        }, {}, {});
        flxSectionHeaderTemplate.setDefaultUnit(voltmx.flex.DP);
        var lblHeading = new voltmx.ui.Label({
            "centerY": "50%",
            "id": "lblHeading",
            "isVisible": true,
            "left": "4%",
            "maxWidth": "50%",
            "skin": "sknSectionHeaderLabelSkin",
            "text": "Heading",
            "textStyle": {},
            "width": "75%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxSectionHeaderTemplate.add(lblHeading);
        return flxSectionHeaderTemplate;
    }
})
;
define("userflxSampleRowTemplateController", {
    //Type your controller code here 
});
define("flxSampleRowTemplateControllerActions", {
    /* 
    This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("flxSampleRowTemplateController", ["userflxSampleRowTemplateController", "flxSampleRowTemplateControllerActions"], function() {
    var controller = require("userflxSampleRowTemplateController");
    var controllerActions = ["flxSampleRowTemplateControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});

define("userflxSectionHeaderTemplateController", {
    //Type your controller code here 
});
define("flxSectionHeaderTemplateControllerActions", {
    /* 
    This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("flxSectionHeaderTemplateController", ["userflxSectionHeaderTemplateController", "flxSectionHeaderTemplateControllerActions"], function() {
    var controller = require("userflxSectionHeaderTemplateController");
    var controllerActions = ["flxSectionHeaderTemplateControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});

require(['applicationController','com/technip/admindemo/AppHeader/AppHeaderController','com/technip/admindemo/AppHeader/AppHeader','com/technip/admindemo/AppHeader/AppHeaderConfig','com/technip/admindemo/LeftMenu/LeftMenuController','com/technip/admindemo/LeftMenu/LeftMenu','com/technip/admindemo/LeftMenu/LeftMenuConfig','com/technip/admindemo/ObservationListElement/ObservationListElementController','com/technip/admindemo/ObservationListElement/ObservationListElement','com/technip/admindemo/ObservationListElement/ObservationListElementConfig','com/technip/admindemo/PortletHeader/PortletHeaderController','com/technip/admindemo/PortletHeader/PortletHeader','com/technip/admindemo/PortletHeader/PortletHeaderConfig','com/technip/admindemo/PortletListElement/PortletListElementController','com/technip/admindemo/PortletListElement/PortletListElement','com/technip/admindemo/PortletListElement/PortletListElementConfig','com/technip/admindemo/PortletPieFooterElement/PortletPieFooterElementController','com/technip/admindemo/PortletPieFooterElement/PortletPieFooterElement','com/technip/admindemo/PortletPieFooterElement/PortletPieFooterElementConfig','com/technip/admindemo/ShadowBottom/ShadowBottomController','com/technip/admindemo/ShadowBottom/ShadowBottom','com/technip/admindemo/ShadowRight/ShadowRightController','com/technip/admindemo/ShadowRight/ShadowRight','com/technip/admindemo/PortletBar/PortletBarController','com/technip/admindemo/PortletBar/PortletBar','com/technip/admindemo/PortletBar/PortletBarConfig','com/technip/admindemo/PortletList/PortletListController','com/technip/admindemo/PortletList/PortletList','com/technip/admindemo/PortletList/PortletListConfig','com/technip/admindemo/PortletPieFooter/PortletPieFooterController','com/technip/admindemo/PortletPieFooter/PortletPieFooter','com/technip/admindemo/PortletPieFooter/PortletPieFooterConfig','com/technip/admindemo/PortletTask/PortletTaskController','com/technip/admindemo/PortletTask/PortletTask','com/technip/admindemo/PortletTask/PortletTaskConfig','com/technip/admindemo/PortletPie/PortletPieController','com/technip/admindemo/PortletPie/PortletPie','com/technip/admindemo/PortletPie/PortletPieConfig','flxSampleRowTemplate','flxSectionHeaderTemplate','flxSampleRowTemplateController','flxSectionHeaderTemplateController'], function(){});

define("sparequirefileslist", function(){});

