define("userfrmHomeController", {
    onViewCreated() {
        this.view.init = () => {
            //init global data
            kony.application.showLoadingScreen(null, null, constants.LOADING_SCREEN_POSITION_ONLY_CENTER, true, true, {});
            var objSvc = VMXFoundry.getObjectService("ObservationTakenObject", {
                "access": "online"
            });
            var dataObject = new kony.sdk.dto.DataObject("ObservationTaken");
            objSvc.fetch({
                dataObject: dataObject
            }, (response) => {
                const observationList = response.records;
                observationList.sort((a, b) => {
                    return a.LastUpdatedDateTime <= b.LastUpdatedDateTime ? 1 : -1;
                });
                appData.observationList = observationList;
                //init observation portlet
                const portletListData = [];
                const maxPortletList = Math.min(6, appData.observationList.length);
                for (let i = 0; i < maxPortletList; i++) {
                    const observationElement = appData.observationList[i];
                    portletListData.push({
                        id: observationElement.ObservationId,
                        title: observationElement.LastUpdatedDateTime,
                        status: observationElement.status
                    });
                }
                this.view.portletObservation.data = {
                    data: portletListData
                };
                this.view.portletObservation.reload();
                //init observation list
                this.view.flxObservationList.removeAll();
                appData.observationList.forEach((element, index) => {
                    const cmpObsElement = new com.technip.admindemo.ObservationListElement({
                        id: `cmpObsElement${index}`,
                        top: null,
                        bottom: '24dp'
                    }, {}, {});
                    cmpObsElement.elementId = element.ObservationId;
                    cmpObsElement.title = element.LastUpdatedDateTime;
                    cmpObsElement.name = element.userName;
                    cmpObsElement.status = element.status;
                    this.view.flxObservationList.add(cmpObsElement);
                });
                kony.application.dismissLoadingScreen();
            });
            this.view.leftMenu.onMenuSelect = (menuItem) => {
                this.view.flxDashboard.isVisible = menuItem === 'dashboard';
                this.view.flxObservation.isVisible = menuItem === 'observation';
            };
            this.view.portletObservation.onSelectElement = (elementId) => {
                alert(elementId);
            };
        };
    }
});
define("frmHomeControllerActions", {
    /* 
    This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("frmHomeController", ["userfrmHomeController", "frmHomeControllerActions"], function() {
    var controller = require("userfrmHomeController");
    var controllerActions = ["frmHomeControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
