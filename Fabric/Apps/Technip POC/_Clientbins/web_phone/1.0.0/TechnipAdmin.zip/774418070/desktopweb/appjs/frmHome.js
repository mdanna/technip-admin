define("frmHome", function() {
    return function(controller) {
        function addWidgetsfrmHome() {
            this.setDefaultUnit(voltmx.flex.DP);
            var flxRoot = new voltmx.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxRoot",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": voltmx.flex.SCROLL_BOTH,
                "skin": "CopysknFlxGradient0d0da766f6eb347",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {}, {});
            flxRoot.setDefaultUnit(voltmx.flex.DP);
            var shadowBottom1 = new com.technip.admindemo.ShadowBottom({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "height": "10dp",
                "id": "shadowBottom1",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxShadowBottom",
                "top": "96dp",
                "width": "100%",
                "zIndex": 1,
                "overrides": {
                    "ShadowBottom": {
                        "height": "10dp",
                        "left": "0dp",
                        "top": "96dp",
                        "width": "100%"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            var leftMenu = new com.technip.admindemo.LeftMenu({
                "height": "928dp",
                "id": "leftMenu",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "sknFlxWhite",
                "top": "96dp",
                "width": "255dp",
                "zIndex": 1,
                "overrides": {
                    "LeftMenu": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            var shadowBottom2 = new com.technip.admindemo.ShadowBottom({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "height": "10dp",
                "id": "shadowBottom2",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxShadowBottom",
                "top": "1024dp",
                "width": "265dp",
                "zIndex": 1,
                "overrides": {
                    "ShadowBottom": {
                        "height": "10dp",
                        "left": "0dp",
                        "top": "1024dp",
                        "width": "265dp"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            var ShadowRight = new com.technip.admindemo.ShadowRight({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "height": "928dp",
                "id": "ShadowRight",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "255dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxShadowRight",
                "top": "101dp",
                "width": "10dp",
                "zIndex": 1,
                "overrides": {
                    "ShadowRight": {
                        "height": "928dp",
                        "left": "255dp",
                        "top": "101dp"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxDashboard = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1068dp",
                "id": "flxDashboard",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "265dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "106dp",
                "width": "1175dp",
                "zIndex": 1
            }, {}, {});
            flxDashboard.setDefaultUnit(voltmx.flex.DP);
            var flxTop = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "475dp",
                "id": "flxTop",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "22dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "22dp",
                "width": "1143dp",
                "zIndex": 1
            }, {}, {});
            flxTop.setDefaultUnit(voltmx.flex.DP);
            var portletObservation = new com.technip.admindemo.PortletList({
                "height": "475dp",
                "id": "portletObservation",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFlxWhiteBorderGrey",
                "top": "0dp",
                "width": "392dp",
                "zIndex": 1,
                "overrides": {
                    "PortletList": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            portletObservation.data = {
                "data": [{
                    "id": "card4",
                    "status": "Missed",
                    "title": "2021-11-29 15:25:27"
                }, {
                    "id": "card5",
                    "status": "Assigned",
                    "title": "2021-11-27 11:38:40"
                }, {
                    "id": "card6",
                    "status": "Assigned",
                    "title": "2021-10-24 11:20:42"
                }, {
                    "id": "cardpippo",
                    "status": "Opened",
                    "title": "2021-11-20 09:46:51"
                }],
                "schema": [{
                    "columnHeaderTemplate": null,
                    "columnHeaderText": "id",
                    "columnHeaderType": "text",
                    "columnID": "id",
                    "columnText": "Not Defined",
                    "columnType": "text",
                    "kuid": "fe9a9dfaca974577980d47be92da797a"
                }, {
                    "columnHeaderTemplate": null,
                    "columnHeaderText": "title",
                    "columnHeaderType": "text",
                    "columnID": "title",
                    "columnText": "Not Defined",
                    "columnType": "text",
                    "kuid": "hd2544ad1f5f462985f09e5fbf13c63a"
                }, {
                    "columnHeaderTemplate": null,
                    "columnHeaderText": "status",
                    "columnHeaderType": "text",
                    "columnID": "status",
                    "columnText": "Not Defined",
                    "columnType": "text",
                    "kuid": "f9b7ce63e6cc4d9e8e3142fc5653e9f0"
                }]
            };
            var portletPie = new com.technip.admindemo.PortletPie({
                "height": "475dp",
                "id": "portletPie",
                "isVisible": true,
                "left": "24dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFlxWhiteBorderGrey",
                "top": "0dp",
                "width": "371dp",
                "zIndex": 1,
                "overrides": {
                    "PortletPie": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            var portletBar = new com.technip.admindemo.PortletBar({
                "height": "475dp",
                "id": "portletBar",
                "isVisible": true,
                "left": "24dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFlxWhiteBorderGrey",
                "top": "0dp",
                "width": "306dp",
                "zIndex": 1,
                "overrides": {
                    "PortletBar": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxTop.add(portletObservation, portletPie, portletBar);
            var flxBottom = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "475dp",
                "id": "flxBottom",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "22dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "24dp",
                "width": "1143dp",
                "zIndex": 1
            }, {}, {});
            flxBottom.setDefaultUnit(voltmx.flex.DP);
            var portletTask = new com.technip.admindemo.PortletTask({
                "height": "475dp",
                "id": "portletTask",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFlxWhiteBorderGrey",
                "top": "0dp",
                "width": "701dp",
                "zIndex": 1,
                "overrides": {
                    "PortletTask": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            var portletInspection = new com.technip.admindemo.PortletList({
                "height": "475dp",
                "id": "portletInspection",
                "isVisible": true,
                "left": "24dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFlxWhiteBorderGrey",
                "top": "0dp",
                "width": "392dp",
                "zIndex": 1,
                "overrides": {
                    "portletHeader.lblTitle": {
                        "text": "Vehicle Inspection Requests"
                    },
                    "PortletList": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            portletInspection.data = {
                "data": [{
                    "id": "card4",
                    "status": "Missed",
                    "title": "2021-11-29 15:25:27"
                }, {
                    "id": "card5",
                    "status": "Assigned",
                    "title": "2021-11-27 11:38:40"
                }, {
                    "id": "card6",
                    "status": "Assigned",
                    "title": "2021-10-24 11:20:42"
                }, {
                    "id": "cardpippo",
                    "status": "Opened",
                    "title": "2021-11-20 09:46:51"
                }],
                "schema": [{
                    "columnHeaderTemplate": null,
                    "columnHeaderText": "id",
                    "columnHeaderType": "text",
                    "columnID": "id",
                    "columnText": "Not Defined",
                    "columnType": "text",
                    "kuid": "fe9a9dfaca974577980d47be92da797a"
                }, {
                    "columnHeaderTemplate": null,
                    "columnHeaderText": "title",
                    "columnHeaderType": "text",
                    "columnID": "title",
                    "columnText": "Not Defined",
                    "columnType": "text",
                    "kuid": "hd2544ad1f5f462985f09e5fbf13c63a"
                }, {
                    "columnHeaderTemplate": null,
                    "columnHeaderText": "status",
                    "columnHeaderType": "text",
                    "columnID": "status",
                    "columnText": "Not Defined",
                    "columnType": "text",
                    "kuid": "f9b7ce63e6cc4d9e8e3142fc5653e9f0"
                }]
            };
            flxBottom.add(portletTask, portletInspection);
            flxDashboard.add(flxTop, flxBottom);
            var flxObservation = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1068dp",
                "id": "flxObservation",
                "isVisible": false,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "265dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "106dp",
                "width": "1175dp",
                "zIndex": 1
            }, {}, {});
            flxObservation.setDefaultUnit(voltmx.flex.DP);
            var flxObservationContent = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxObservationContent",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxWhite",
                "top": "0dp",
                "width": "700dp",
                "zIndex": 1
            }, {}, {});
            flxObservationContent.setDefaultUnit(voltmx.flex.DP);
            var observationHeader = new com.technip.admindemo.PortletHeader({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "observationHeader",
                "isVisible": true,
                "left": "40dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "40dp",
                "width": "620dp",
                "zIndex": 1,
                "overrides": {
                    "flxBottom": {
                        "isVisible": false
                    },
                    "imgZoom": {
                        "isVisible": false
                    },
                    "PortletHeader": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "height": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxObservationList = new voltmx.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "bounces": true,
                "centerX": "50%",
                "clipBounds": true,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxObservationList",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "maxHeight": "896dp",
                "minHeight": "64dp",
                "pagingEnabled": false,
                "scrollDirection": voltmx.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "24dp",
                "verticalScrollIndicator": true,
                "width": "620dp",
                "zIndex": 1
            }, {}, {});
            flxObservationList.setDefaultUnit(voltmx.flex.DP);
            var ObservationListElement = new com.technip.admindemo.ObservationListElement({
                "bottom": "24dp",
                "height": "40dp",
                "id": "ObservationListElement",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 0,
                "width": "620dp",
                "zIndex": 1,
                "overrides": {
                    "lblTitle": {
                        "text": "Pippo"
                    },
                    "ObservationListElement": {
                        "right": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            ObservationListElement.status = "Opened";
            ObservationListElement.elementId = "pippo";
            var CopyObservationListElement0f05cd22577d349 = new com.technip.admindemo.ObservationListElement({
                "bottom": "24dp",
                "height": "40dp",
                "id": "CopyObservationListElement0f05cd22577d349",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 0,
                "width": "620dp",
                "zIndex": 1,
                "overrides": {
                    "lblTitle": {
                        "text": "Pippo"
                    },
                    "ObservationListElement": {
                        "right": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            CopyObservationListElement0f05cd22577d349.status = "Assigned";
            CopyObservationListElement0f05cd22577d349.elementId = "pippo";
            var CopyObservationListElement0fb3740dc5a6d4d = new com.technip.admindemo.ObservationListElement({
                "bottom": "24dp",
                "height": "40dp",
                "id": "CopyObservationListElement0fb3740dc5a6d4d",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 0,
                "width": "620dp",
                "zIndex": 1,
                "overrides": {
                    "lblTitle": {
                        "text": "Pippo"
                    },
                    "ObservationListElement": {
                        "right": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            CopyObservationListElement0fb3740dc5a6d4d.status = "Missed";
            CopyObservationListElement0fb3740dc5a6d4d.elementId = "pippo";
            var CopyObservationListElement0b51d1b1e98404b = new com.technip.admindemo.ObservationListElement({
                "bottom": "24dp",
                "height": "40dp",
                "id": "CopyObservationListElement0b51d1b1e98404b",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 0,
                "width": "620dp",
                "zIndex": 1,
                "overrides": {
                    "lblTitle": {
                        "text": "Pippo"
                    },
                    "ObservationListElement": {
                        "right": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            CopyObservationListElement0b51d1b1e98404b.status = "Opened";
            CopyObservationListElement0b51d1b1e98404b.elementId = "pippo";
            flxObservationList.add(ObservationListElement, CopyObservationListElement0f05cd22577d349, CopyObservationListElement0fb3740dc5a6d4d, CopyObservationListElement0b51d1b1e98404b);
            flxObservationContent.add(observationHeader, flxObservationList);
            flxObservation.add(flxObservationContent);
            var AppHeader = new com.technip.admindemo.AppHeader({
                "height": "96dp",
                "id": "AppHeader",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "sknFlxWhite",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "overrides": {
                    "AppHeader": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxRoot.add(shadowBottom1, leftMenu, shadowBottom2, ShadowRight, flxDashboard, flxObservation, AppHeader);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1440,
            }
            this.compInstData = {
                "shadowBottom1": {
                    "height": "10dp",
                    "left": "0dp",
                    "top": "96dp",
                    "width": "100%"
                },
                "leftMenu": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "shadowBottom2": {
                    "height": "10dp",
                    "left": "0dp",
                    "top": "1024dp",
                    "width": "265dp"
                },
                "ShadowRight": {
                    "height": "928dp",
                    "left": "255dp",
                    "top": "101dp"
                },
                "portletObservation": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "portletPie": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "portletBar": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "portletTask": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "portletInspection": {
                    "title": "Vehicle Inspection Requests",
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "observationHeader": {
                    "right": "",
                    "bottom": "",
                    "height": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "ObservationListElement": {
                    "title": "Pippo",
                    "right": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "CopyObservationListElement0f05cd22577d349": {
                    "title": "Pippo",
                    "right": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "CopyObservationListElement0fb3740dc5a6d4d": {
                    "title": "Pippo",
                    "right": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "CopyObservationListElement0b51d1b1e98404b": {
                    "title": "Pippo",
                    "right": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "AppHeader": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                }
            }
            this.add(flxRoot);
        };
        return [{
            "addWidgets": addWidgetsfrmHome,
            "enabledForIdleTimeout": false,
            "id": "frmHome",
            "layoutType": voltmx.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1440]
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": voltmx.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});